// Top-level equipment categories. Only `uav` is populated today.
// To add a category: add it here, then add products with `category: '<id>'` in products.js.
export const CATEGORIES = [
  { id: 'weapons', label: 'Weapons' },
  { id: 'uav', label: 'UAV Systems' },
  { id: 'vehicles', label: 'Vehicles' },
  { id: 'gear', label: 'Tactical Gear' },
  { id: 'comms', label: 'Communication' },
  { id: 'electronics', label: 'Electronics' },
];

export const DEFAULT_CATEGORY = 'uav';

export const getCategory = (id) => CATEGORIES.find((c) => c.id === id);
