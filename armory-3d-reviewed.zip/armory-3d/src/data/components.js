import { getModelSpec } from './models';

// General, educational descriptions of multirotor components.
// These describe what the PART TYPE does in general — they are NOT product specifications.
export const COMPONENT_LIBRARY = {
  body: {
    label: 'Main Body',
    role: 'Structure',
    description:
      'The central housing of a multirotor. It usually holds the flight controller, battery and wiring, and is the structure every other part attaches to.',
  },
  arms: {
    label: 'Arms',
    role: 'Structure',
    description:
      'Booms that carry the motors away from the centre of the aircraft. Their length sets the spacing between rotors and helps keep the propellers clear of the body.',
  },
  foldingArms: {
    label: 'Folding Arms',
    role: 'Structure',
    description:
      'Arms attached with hinges so they can fold in toward the body for transport and swing out and lock for flight.',
  },
  motors: {
    label: 'Motors',
    role: 'Propulsion',
    description:
      'Electric motors spin the propellers. Each motor is driven independently, and differences in their speed are how a quadcopter climbs, tilts and turns.',
  },
  propellers: {
    label: 'Propellers',
    role: 'Propulsion',
    description:
      'Rotating blades that convert motor rotation into thrust. Neighbouring propellers usually spin in opposite directions to cancel out torque.',
  },
  guards: {
    label: 'Propeller Guards',
    role: 'Protection',
    description:
      'Open rings around the propellers that help protect the blades, and anything they might touch, during bumps and collisions.',
  },
  landing: {
    label: 'Landing Supports',
    role: 'Structure',
    description:
      'Legs or skids that hold the body off the ground when the aircraft is resting, and absorb part of the impact when it lands.',
  },
  cameraHousing: {
    label: 'Camera Housing',
    role: 'Payload',
    description:
      'The enclosure that holds the camera and lens at the front of the aircraft and keeps them protected from knocks and dust.',
  },
  cameraModule: {
    label: 'Camera Module',
    role: 'Payload',
    description:
      'The camera and lens assembly. On many foldable designs it hangs from a small mount at the front of the body so it has a clear view forward.',
  },
  ducts: {
    label: 'Ducted Fan Housings',
    role: 'Protection',
    description:
      'Closed rings that surround each propeller. They shield the spinning blades from contact and let the aircraft be handled and flown close to objects.',
  },
  supports: {
    label: 'Structural Supports',
    role: 'Structure',
    description:
      'Struts and spokes that tie the duct rings to the body and hold each propeller assembly in position.',
  },
};

export const getComponentInfo = (id) =>
  COMPONENT_LIBRARY[id] ?? { label: id, role: 'Component', description: '' };

/**
 * Ordered component groups for a product, with live part counts taken from its 3D model spec.
 * Order follows product.components.
 */
export function getProductGroups(product) {
  const spec = getModelSpec(product.model.id);
  const counts = {};
  spec?.parts.forEach((p) => {
    counts[p.group] = (counts[p.group] ?? 0) + 1;
  });
  return product.components.map((id) => ({
    id,
    ...getComponentInfo(id),
    count: counts[id] ?? 0,
  }));
}
