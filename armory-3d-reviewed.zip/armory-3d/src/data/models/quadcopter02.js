import { part } from '../../utils/modelHelpers';

// VISUAL PROXY for QUADCOPTER 02 (white body, four enclosed ducted rotors, front camera housing).
// Built from primitives — not a dimensionally accurate reproduction.

const X = 0.9; // duct centre offset along the body (front/back)
const Z = 1.15; // duct centre offset sideways
const DUCT_R = 0.7;
const DUCT_T = 0.1;
const CORNERS = [
  [1, 1],
  [1, -1],
  [-1, 1],
  [-1, -1],
];

const materials = {
  white: { color: '#eef0f1', metalness: 0.05, roughness: 0.28, clearcoat: 0.6, clearcoatRoughness: 0.2 },
  whiteSoft: { color: '#dfe3e5', metalness: 0.05, roughness: 0.45 },
  graphite: { color: '#2a2f33', metalness: 0.4, roughness: 0.5 },
  black: { color: '#111315', metalness: 0.1, roughness: 0.5 },
  lens: { color: '#05080b', metalness: 0.9, roughness: 0.05 },
};

const parts = [
  part('body-main', 'body', 'capsule', [0.34, 1.2, 8, 24], 'white', {
    rot: [0, 0, Math.PI / 2],
    scale: [0.75, 1, 1],
    explode: [0, 0.3, 0],
    delay: 0.25,
  }),
  part('body-cover', 'body', 'rbox', [0.9, 0.16, 0.4, 4, 0.07], 'whiteSoft', {
    pos: [-0.1, 0.2, 0],
    explode: [0, 1.0, 0],
    delay: 0.2,
  }),
  part('cam-housing', 'cameraHousing', 'rbox', [0.55, 0.42, 0.58, 4, 0.13], 'white', {
    pos: [0.62, 0.1, 0],
    explode: [0.9, 0.45, 0],
    delay: 0.15,
  }),
  part('cam-lens', 'cameraHousing', 'sphere', [0.17, 24, 16], 'lens', {
    pos: [0.9, 0.1, 0],
    explode: [1.25, 0.45, 0],
    delay: 0.15,
  }),
  part('cam-ring', 'cameraHousing', 'torus', [0.17, 0.025, 8, 28], 'graphite', {
    pos: [0.88, 0.1, 0],
    rot: [0, Math.PI / 2, 0],
    explode: [1.25, 0.45, 0],
    delay: 0.15,
  }),
];

CORNERS.forEach(([sx, sz], i) => {
  const cx = sx * X;
  const cz = sz * Z;
  parts.push(
    part(`duct-${i}`, 'ducts', 'torus', [DUCT_R, DUCT_T, 20, 56], 'white', {
      pos: [cx, 0, cz],
      rot: [Math.PI / 2, 0, 0],
      explode: [sx * 0.9, 0, sz * 1.0],
      delay: 0.1,
    }),
    part(`hub-${i}`, 'motors', 'cyl', [0.09, 0.09, 0.16, 20], 'graphite', {
      pos: [cx, -0.02, cz],
      explode: [sx * 0.9, 0.45, sz * 1.0],
      delay: 0.1,
    }),
    part(`prop-${i}`, 'propellers', 'prop', [0.5, 0.11, 0.014], 'black', {
      pos: [cx, 0.06, cz],
      rot: [0, i * 0.8, 0],
      spin: i % 2 === 0 ? 1 : -1,
      explode: [sx * 0.9, 1.1, sz * 1.0],
    }),
    part(`support-${i}`, 'supports', 'cyl', [0.04, 0.04, 1.69, 12], 'whiteSoft', {
      pos: [cx, -0.12, sz * 1.005],
      rot: [Math.PI / 2, 0, 0],
      explode: [sx * 0.9, -0.4, sz * 1.0],
      delay: 0.1,
    })
  );
});

export default { id: 'quadcopter-02', hover: 0.7, materials, parts };
