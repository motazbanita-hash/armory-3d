import { deg, polar, strut, part } from '../../utils/modelHelpers';

// VISUAL PROXY for QUADCOPTER 01 (red quadcopter, black open guards, landing supports).
// Built from primitives — not a dimensionally accurate reproduction.
// Edit `explode` vectors / `delay` values to change the exploded layout.

const ANGLES = [45, 135, 225, 315].map(deg);
const R = 1.15; // distance of each motor from the centre

const materials = {
  red: { color: '#b3141a', metalness: 0.35, roughness: 0.22, clearcoat: 1, clearcoatRoughness: 0.08 },
  redDeep: { color: '#7a0c11', metalness: 0.3, roughness: 0.4 },
  black: { color: '#14171a', metalness: 0.1, roughness: 0.55 },
  rubber: { color: '#0d0f11', metalness: 0, roughness: 0.9 },
  lens: { color: '#05080b', metalness: 0.9, roughness: 0.08 },
};

const parts = [
  part('body-shell', 'body', 'rbox', [1.2, 0.26, 0.98, 4, 0.11], 'red', { explode: [0, 0.45, 0], delay: 0.25 }),
  part('body-canopy', 'body', 'sphere', [0.42, 32, 16], 'red', {
    pos: [0, 0.12, 0],
    scale: [1.25, 0.4, 1.0],
    explode: [0, 1.0, 0],
    delay: 0.2,
  }),
  part('body-belly', 'body', 'rbox', [0.85, 0.14, 0.72, 3, 0.05], 'black', {
    pos: [0, -0.18, 0],
    explode: [0, -0.35, 0],
    delay: 0.25,
  }),
  part('body-lens', 'body', 'sphere', [0.09, 16, 12], 'lens', {
    pos: [0.5, -0.14, 0],
    explode: [0.45, -0.55, 0],
    delay: 0.25,
  }),
];

ANGLES.forEach((a, i) => {
  const spin = i % 2 === 0 ? 1 : -1;
  parts.push(
    part(`arm-${i}`, 'arms', 'box', [R * 0.95, 0.09, 0.15], 'redDeep', {
      pos: polar(R * 0.5, a, 0),
      rot: [0, -a, 0],
      explode: polar(0.5, a, 0.1),
      delay: 0.2,
    }),
    part(`motor-${i}`, 'motors', 'cyl', [0.17, 0.17, 0.22, 24], 'redDeep', {
      pos: polar(R, a, 0.1),
      explode: polar(1.0, a, 0.35),
      delay: 0.1,
    }),
    part(`prop-${i}`, 'propellers', 'prop', [0.52, 0.075, 0.014], 'black', {
      pos: polar(R, a, 0.27),
      rot: [0, a + i * 0.4, 0],
      spin,
      explode: polar(1.0, a, 1.15),
    }),
    part(`guard-ring-${i}`, 'guards', 'torus', [0.64, 0.022, 8, 48], 'black', {
      pos: polar(R, a, 0.12),
      rot: [Math.PI / 2, 0, 0],
      explode: polar(1.0, a, -0.25),
      delay: 0.05,
    }),
    part(`guard-strut-${i}`, 'guards', 'box', [0.64, 0.04, 0.05], 'black', {
      pos: polar(R + 0.32, a, 0.12),
      rot: [0, -a, 0],
      explode: polar(1.0, a, -0.25),
      delay: 0.05,
    })
  );

  const leg = strut(a, 0.3, -0.15, 0.78, -0.78);
  parts.push(
    part(`leg-${i}`, 'landing', 'cyl', [0.04, 0.045, leg.length, 12], 'black', {
      pos: leg.pos,
      rot: leg.rot,
      explode: polar(0.35, a, -0.8),
      delay: 0.15,
    }),
    part(`foot-${i}`, 'landing', 'sphere', [0.07, 12, 10], 'rubber', {
      pos: polar(0.78, a, -0.78),
      scale: [1.4, 0.6, 1.4],
      explode: polar(0.35, a, -0.8),
      delay: 0.15,
    })
  );
});

export default { id: 'quadcopter-01', hover: 0.04, materials, parts };
