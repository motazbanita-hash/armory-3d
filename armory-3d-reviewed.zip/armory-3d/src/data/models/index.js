import q01 from './quadcopter01';
import q02 from './quadcopter02';
import q03 from './quadcopter03';

// Registry of 3D model specs, keyed by product.model.id.
// Add one file per new product and register it here.
export const MODEL_SPECS = {
  [q01.id]: q01,
  [q02.id]: q02,
  [q03.id]: q03,
};

export const getModelSpec = (id) => MODEL_SPECS[id];
