import { deg, polar, part } from '../../utils/modelHelpers';

// VISUAL PROXY for QUADCOPTER 03 (black foldable quadcopter, four arms, front camera module).
// Built from primitives — not a dimensionally accurate reproduction.

const ANGLES = [50, 130, 230, 310].map(deg);
const R = 1.5; // motor distance from centre

const materials = {
  black: { color: '#16191c', metalness: 0.2, roughness: 0.45 },
  blackSoft: { color: '#1f2428', metalness: 0.15, roughness: 0.6 },
  lens: { color: '#05080b', metalness: 0.9, roughness: 0.05 },
  metal: { color: '#b9b4a8', metalness: 0.95, roughness: 0.28 },
  hinge: { color: '#7d786e', metalness: 0.9, roughness: 0.35 },
};

const parts = [
  part('body-shell', 'body', 'rbox', [1.05, 0.3, 0.72, 5, 0.12], 'black', { explode: [0, 0.3, 0], delay: 0.25 }),
  part('body-top', 'body', 'rbox', [0.86, 0.12, 0.58, 4, 0.05], 'blackSoft', {
    pos: [0, 0.18, 0],
    explode: [0, 0.9, 0],
    delay: 0.2,
  }),
  part('body-under', 'body', 'rbox', [0.6, 0.1, 0.5, 3, 0.04], 'blackSoft', {
    pos: [-0.15, -0.17, 0],
    explode: [-0.3, -0.6, 0],
    delay: 0.25,
  }),
  part('cam-mount', 'cameraModule', 'rbox', [0.3, 0.12, 0.36, 3, 0.04], 'blackSoft', {
    pos: [0.5, -0.2, 0],
    explode: [0.6, -0.4, 0],
    delay: 0.15,
  }),
  part('cam-body', 'cameraModule', 'rbox', [0.3, 0.3, 0.34, 4, 0.09], 'black', {
    pos: [0.62, -0.38, 0],
    explode: [0.9, -0.8, 0],
    delay: 0.15,
  }),
  part('cam-lens', 'cameraModule', 'cyl', [0.1, 0.1, 0.14, 24], 'lens', {
    pos: [0.8, -0.38, 0],
    rot: [0, 0, Math.PI / 2],
    explode: [1.2, -0.8, 0],
    delay: 0.15,
  }),
];

ANGLES.forEach((a, i) => {
  parts.push(
    part(`hinge-${i}`, 'foldingArms', 'cyl', [0.1, 0.1, 0.22, 20], 'hinge', {
      pos: polar(0.5, a, 0),
      explode: polar(0.5, a, 0.15),
      delay: 0.2,
    }),
    part(`arm-${i}`, 'foldingArms', 'box', [0.95, 0.085, 0.17], 'black', {
      pos: polar(0.5 + 0.475, a, 0),
      rot: [0, -a, 0],
      explode: polar(0.9, a, 0.2),
      delay: 0.15,
    }),
    part(`motor-${i}`, 'motors', 'cyl', [0.14, 0.14, 0.24, 24], 'metal', {
      pos: polar(R, a, 0.1),
      explode: polar(1.3, a, 0.4),
      delay: 0.05,
    }),
    part(`motor-cap-${i}`, 'motors', 'cyl', [0.1, 0.1, 0.06, 24], 'black', {
      pos: polar(R, a, 0.25),
      explode: polar(1.3, a, 0.4),
      delay: 0.05,
    }),
    part(`prop-${i}`, 'propellers', 'prop', [0.68, 0.11, 0.014], 'black', {
      pos: polar(R, a, 0.34),
      rot: [0, i * 0.5 + 0.3, 0],
      spin: i % 2 === 0 ? 1 : -1,
      explode: polar(1.3, a, 1.2),
    })
  );
});

export default { id: 'quadcopter-03', hover: 0.7, materials, parts };
