import { getCategory } from './categories';

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCT DATABASE — plain data, no UI code.
//
// Rules for this catalog:
//  • Only the three supplied quadcopters exist. No invented products.
//  • No invented manufacturer names, model numbers or performance figures.
//    Unknown specifications are left out of `specs` and render as "Not provided".
//  • `visual` rows are observations of the supplied reference photos only.
//
// To fill in a real spec later, add it to the product's `specs`, e.g.
//   specs: { 'Flight time': '25 min' }
// ─────────────────────────────────────────────────────────────────────────────

const BASE = (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.BASE_URL) || '/';
const asset = (path) => `${BASE}${path}`.replace(/\/{2,}/g, '/');

export const NOT_PROVIDED = 'Not provided';

// The specification fields every product shows, in order.
export const SPEC_FIELDS = [
  'Manufacturer',
  'Model number',
  'Flight time',
  'Range',
  'Weight',
  'Dimensions',
  'Camera',
  'Battery',
];

export const PRODUCTS = [
  {
    id: 'quadcopter-01',
    category: 'uav',
    identifier: 'QUADCOPTER 01',
    name: 'Red Quadcopter',
    tag: 'RED',
    image: asset('images/quadcopter-01.jpg'),
    description:
      'A compact, recreational-style quadcopter with a glossy red central body, four propellers protected by black guards, and landing supports.',
    features: [
      'Red central body',
      'Four propellers',
      'Black propeller guards',
      'Landing supports',
      'Compact recreational appearance',
    ],
    visual: [
      { label: 'Body colour', value: 'Red' },
      { label: 'Propellers', value: 'Four' },
      { label: 'Rotor protection', value: 'Open black guards' },
      { label: 'Landing supports', value: 'Yes' },
      { label: 'Folding arms', value: 'No' },
      { label: 'Camera', value: 'Not clearly visible' },
    ],
    specs: {},
    components: ['body', 'arms', 'motors', 'propellers', 'guards', 'landing'],
    model: { id: 'quadcopter-01', glb: null },
  },
  {
    id: 'quadcopter-02',
    category: 'uav',
    identifier: 'QUADCOPTER 02',
    name: 'White Ducted Quadcopter',
    tag: 'WHITE',
    image: asset('images/quadcopter-02.jpg'),
    description:
      'A compact, integrated design with a white body and four propellers enclosed in circular ducted rotor guards.',
    features: [
      'White body',
      'Enclosed circular rotor guards',
      'Four ducted propulsion units',
      'Compact integrated design',
    ],
    visual: [
      { label: 'Body colour', value: 'White' },
      { label: 'Propellers', value: 'Four' },
      { label: 'Rotor protection', value: 'Enclosed duct rings' },
      { label: 'Landing supports', value: 'Not visible' },
      { label: 'Folding arms', value: 'No' },
      { label: 'Camera', value: 'Front camera housing' },
    ],
    specs: {},
    components: ['body', 'cameraHousing', 'ducts', 'motors', 'propellers', 'supports'],
    model: { id: 'quadcopter-02', glb: null },
  },
  {
    id: 'quadcopter-03',
    category: 'uav',
    identifier: 'QUADCOPTER 03',
    name: 'Black Foldable Quadcopter',
    tag: 'BLACK',
    image: asset('images/quadcopter-03.jpg'),
    description:
      'A black foldable quadcopter with four folding arms, four propellers and a front camera module.',
    features: ['Black body', 'Four folding arms', 'Four propellers', 'Front camera module', 'Foldable design'],
    visual: [
      { label: 'Body colour', value: 'Black' },
      { label: 'Propellers', value: 'Four' },
      { label: 'Rotor protection', value: 'None (open propellers)' },
      { label: 'Landing supports', value: 'Not visible' },
      { label: 'Folding arms', value: 'Yes' },
      { label: 'Camera', value: 'Front camera module' },
    ],
    specs: {},
    components: ['body', 'foldingArms', 'motors', 'propellers', 'cameraModule'],
    model: { id: 'quadcopter-03', glb: null },
  },
];

export const getProduct = (id) => PRODUCTS.find((p) => p.id === id);
export const productsInCategory = (categoryId) => PRODUCTS.filter((p) => p.category === categoryId);

/** Spec rows for a product: every SPEC_FIELDS entry, falling back to "Not provided". */
export function getSpecRows(product) {
  return SPEC_FIELDS.map((label) => ({
    label,
    value: product.specs?.[label] ?? NOT_PROVIDED,
    known: product.specs?.[label] != null,
  }));
}

/** Search by name, identifier, tag, category label and description. */
export function searchProducts(query, { categoryId = null } = {}) {
  const q = query.trim().toLowerCase();
  return PRODUCTS.filter((p) => {
    if (categoryId && p.category !== categoryId) return false;
    if (!q) return true;
    const hay = [p.name, p.identifier, p.tag, p.id, getCategory(p.category)?.label, p.description, ...p.features]
      .join(' ')
      .toLowerCase();
    return q.split(/\s+/).every((word) => hay.includes(word));
  });
}
