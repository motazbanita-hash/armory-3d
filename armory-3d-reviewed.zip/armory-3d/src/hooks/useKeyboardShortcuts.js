import { useEffect } from 'react';
import { useArmoryStore } from '../store/useArmoryStore';
import { sfx } from '../utils/audio';

export const SHORTCUTS = [
  ['← / →  or  A / D', 'Previous / next product'],
  ['1 – 9', 'Select product by position'],
  ['I', 'Toggle Cinematic / Inspection'],
  ['E', 'Explode / collapse'],
  ['L', 'Layers panel'],
  ['V', 'Camera views panel'],
  ['O', 'Isolate selected component'],
  ['Space', 'Auto-rotate on / off'],
  ['R', 'Reset experience'],
  ['C', 'Compare products'],
  ['F', 'Fullscreen inspection'],
  ['/  or  Ctrl K', 'Search'],
  ['Esc', 'Deselect / close'],
];

const isTyping = (el) =>
  el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable);

export function useKeyboardShortcuts({ toggleFullscreen, productIds }) {
  useEffect(() => {
    const onKey = (e) => {
      const st = useArmoryStore.getState();
      if (e.key === 'Escape') {
        if (st.searchOpen) return st.setSearchOpen(false);
        if (st.settingsOpen) return st.setSettingsOpen(false);
        if (st.compareOpen) return st.setCompareOpen(false);
        if (st.activePanel) return st.closePanel();
        if (st.selectedGroup) return st.selectGroup(null);
        if (st.focus) return toggleFullscreen();
        return;
      }
      if (isTyping(e.target) || e.altKey || e.metaKey) return;
      // Space / Enter on a focused button must keep its native "press" behaviour
      if (e.key === ' ' && e.target?.tagName === 'BUTTON') return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        return st.setSearchOpen(true);
      }
      if (e.ctrlKey) return;
      if (st.searchOpen || st.settingsOpen || st.compareOpen) return;

      const k = e.key.toLowerCase();
      if (k === 'arrowright' || k === 'd') {
        st.stepProduct(1);
        sfx('product');
      } else if (k === 'arrowleft' || k === 'a') {
        st.stepProduct(-1);
        sfx('product');
      } else if (/^[1-9]$/.test(k) && productIds[Number(k) - 1]) {
        st.selectProduct(productIds[Number(k) - 1]);
        sfx('product');
      } else if (k === 'i') {
        st.setMode(st.mode === 'cinematic' ? 'inspection' : 'cinematic');
        sfx('mode');
      } else if (k === 'e') {
        st.setMode('inspection');
        st.setExplode(st.explode > 0.5 ? 0 : 1);
        sfx('click');
      } else if (k === 'l') st.togglePanel('layers');
      else if (k === 'v') st.togglePanel('views');
      else if (k === 'o') st.toggleIsolate();
      else if (k === ' ') {
        e.preventDefault();
        st.toggleAutoRotate();
        sfx('click');
      } else if (k === 'r') {
        st.resetExperience();
        sfx('back');
      } else if (k === 'c') st.setCompareOpen(true);
      else if (k === 'f') toggleFullscreen();
      else if (k === '/') {
        e.preventDefault();
        st.setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [toggleFullscreen, productIds]);
}
