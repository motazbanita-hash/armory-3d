import { useMediaQuery } from './useMediaQuery';
import { useArmoryStore } from '../store/useArmoryStore';

/** True if the OS asks for reduced motion OR the in-app setting forces it. */
export function useReducedMotion() {
  const system = useMediaQuery('(prefers-reduced-motion: reduce)');
  const motion = useArmoryStore((s) => s.motion);
  return system || motion === 'reduce';
}
