import { useRef } from 'react';

/**
 * Horizontal swipe detection for touch/pen. Returns handlers to spread on an element.
 * onSwipe(+1) = swiped left (next), onSwipe(-1) = swiped right (previous).
 */
export function useSwipe(onSwipe, { threshold = 40 } = {}) {
  const start = useRef(null);
  return {
    onTouchStart: (e) => {
      const t = e.touches[0];
      start.current = { x: t.clientX, y: t.clientY };
    },
    onTouchEnd: (e) => {
      if (!start.current) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - start.current.x;
      const dy = t.clientY - start.current.y;
      start.current = null;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.4) onSwipe(dx < 0 ? 1 : -1);
    },
  };
}
