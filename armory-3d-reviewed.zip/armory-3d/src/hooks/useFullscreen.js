import { useCallback, useEffect } from 'react';
import { useArmoryStore } from '../store/useArmoryStore';

/**
 * "Fullscreen inspection": hides the side panels (focus layout) and, where the browser allows it,
 * puts the page into real fullscreen. On browsers without the Fullscreen API (e.g. iPhone Safari)
 * the focus layout still works.
 */
export function useFullscreen() {
  const focus = useArmoryStore((s) => s.focus);
  const setFocus = useArmoryStore((s) => s.setFocus);

  useEffect(() => {
    const onChange = () => {
      if (!document.fullscreenElement && useArmoryStore.getState().focus) setFocus(false);
    };
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, [setFocus]);

  const toggle = useCallback(async () => {
    const next = !useArmoryStore.getState().focus;
    setFocus(next);
    try {
      if (next && !document.fullscreenElement) await document.documentElement.requestFullscreen?.();
      if (!next && document.fullscreenElement) await document.exitFullscreen?.();
    } catch {
      /* fullscreen refused — the focus layout is still active */
    }
  }, [setFocus]);

  return { focus, toggle };
}
