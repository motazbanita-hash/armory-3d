import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { PRODUCTS, getProduct, productsInCategory } from '../data/products';
import { DEFAULT_CATEGORY } from '../data/categories';

const systemReducedMotion =
  typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

// Everything that belongs to "the current view of one product".
const VIEW_RESET = {
  selectedGroup: null,
  hoveredGroup: null,
  explode: 0,
  hidden: {},
  xray: 0,
  isolate: false,
  bounds: null,
};

let cameraNonce = 0;

export const useArmoryStore = create(
  persist(
    (set, get) => ({
      // ── catalog / selection ──────────────────────────────────────────────
      category: DEFAULT_CATEGORY,
      productId: PRODUCTS[0].id,
      query: '',
      favoritesOnly: false,
      favorites: [],

      // ── viewer state ─────────────────────────────────────────────────────
      mode: 'cinematic', // 'cinematic' | 'inspection'
      tool: 'rotate', // what a primary drag does: 'rotate' | 'pan' | 'zoom'
      autoRotate: !systemReducedMotion,
      selectedGroup: null,
      hoveredGroup: null,
      explode: 0, // 0..1 target (the engine damps toward it)
      hidden: {}, // { [groupId]: true }
      xray: 0, // 0..1 global transparency
      isolate: false,
      bounds: null, // { radius, height, targetY } reported by the loaded model
      cameraCmd: null, // { type, value, nonce }

      // ── ui state ─────────────────────────────────────────────────────────
      activePanel: null, // 'explode' | 'layers' | 'views' | null
      infoOpen: false, // mobile info sheet
      infoTab: 'info', // mobile info sheet tab
      searchOpen: false,
      settingsOpen: false,
      compareOpen: false,
      compare: ['quadcopter-01', 'quadcopter-02'],
      focus: false, // fullscreen inspection layout
      ready: false, // loading screen finished

      // ── persisted settings ───────────────────────────────────────────────
      audioOn: false,
      propSpin: true,
      shadows: true,
      showGrid: true,
      quality: 'auto', // 'auto' | 'low'
      motion: 'system', // 'system' | 'reduce'

      // ── actions: catalog ─────────────────────────────────────────────────
      setCategory: (category) => {
        const first = productsInCategory(category)[0];
        set({ category, ...(first ? { productId: first.id, ...VIEW_RESET } : {}) });
      },
      selectProduct: (id) => {
        const p = getProduct(id);
        if (!p) return;
        set((s) => ({
          productId: id,
          category: p.category,
          ...VIEW_RESET,
          autoRotate: s.mode === 'cinematic' ? !get().isReducedMotion() : s.autoRotate,
        }));
      },
      stepProduct: (dir) => {
        const list = productsInCategory(get().category);
        if (!list.length) return;
        const i = Math.max(0, list.findIndex((p) => p.id === get().productId));
        get().selectProduct(list[(i + dir + list.length) % list.length].id);
      },
      setQuery: (query) => set({ query }),
      toggleFavoritesOnly: () => set((s) => ({ favoritesOnly: !s.favoritesOnly })),
      toggleFavorite: (id) =>
        set((s) => ({
          favorites: s.favorites.includes(id) ? s.favorites.filter((f) => f !== id) : [...s.favorites, id],
        })),

      // ── actions: components / raycasting ─────────────────────────────────
      selectGroup: (id) =>
        set((s) => ({
          selectedGroup: id,
          isolate: id ? s.isolate : false,
          autoRotate: id ? false : s.autoRotate,
          ...(id ? { mode: 'inspection', infoOpen: true, infoTab: 'parts' } : {}),
        })),
      setHover: (id) => set({ hoveredGroup: id }),

      // ── actions: explode / layers ────────────────────────────────────────
      setExplode: (v) => set({ explode: Math.min(1, Math.max(0, v)) }),
      collapse: () => set({ explode: 0 }),
      toggleHidden: (id) => set((s) => ({ hidden: { ...s.hidden, [id]: !s.hidden[id] } })),
      showAllLayers: () => set({ hidden: {}, xray: 0 }),
      soloGroup: (id, allIds) => {
        const hidden = {};
        allIds.forEach((g) => {
          if (g !== id) hidden[g] = true;
        });
        set({ hidden });
      },
      setXray: (v) => set({ xray: Math.min(1, Math.max(0, v)) }),
      toggleIsolate: () =>
        set((s) => (s.selectedGroup ? { isolate: !s.isolate } : { isolate: false })),

      // ── actions: camera / mode ───────────────────────────────────────────
      setMode: (mode) =>
        set((s) =>
          mode === 'cinematic'
            ? {
                mode,
                selectedGroup: null,
                hoveredGroup: null,
                isolate: false,
                activePanel: null,
                tool: 'rotate',
                autoRotate: !get().isReducedMotion(),
                cameraCmd: { type: 'preset', value: 'default', nonce: ++cameraNonce },
              }
            : { mode, autoRotate: false }
        ),
      setTool: (tool) =>
        set((s) => ({ tool, mode: 'inspection', autoRotate: s.mode === 'cinematic' ? false : s.autoRotate })),
      toggleAutoRotate: () => set((s) => ({ autoRotate: !s.autoRotate })),
      cameraCommand: (type, value) => set({ cameraCmd: { type, value, nonce: ++cameraNonce } }),
      setBounds: (bounds) => set({ bounds }),
      resetExperience: () =>
        set((s) => ({
          ...VIEW_RESET,
          bounds: s.bounds,
          tool: 'rotate',
          activePanel: null,
          autoRotate: s.mode === 'cinematic' ? !get().isReducedMotion() : false,
          cameraCmd: { type: 'preset', value: 'default', nonce: ++cameraNonce },
        })),

      // ── actions: ui ──────────────────────────────────────────────────────
      togglePanel: (id) =>
        set((s) => ({
          activePanel: s.activePanel === id ? null : id,
          mode: 'inspection',
          autoRotate: s.mode === 'cinematic' ? false : s.autoRotate,
        })),
      closePanel: () => set({ activePanel: null }),
      setInfoOpen: (infoOpen) => set({ infoOpen }),
      setInfoTab: (infoTab) => set({ infoTab }),
      setSearchOpen: (searchOpen) => set({ searchOpen }),
      setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
      setCompareOpen: (compareOpen) => set({ compareOpen }),
      setCompare: (index, id) =>
        set((s) => {
          const next = [...s.compare];
          next[index] = id;
          return { compare: next };
        }),
      swapCompare: () => set((s) => ({ compare: [s.compare[1], s.compare[0]] })),
      setFocus: (focus) => set({ focus }),
      setReady: () => set({ ready: true }),
      setSetting: (key, value) => set({ [key]: value }),

      // Combines the OS preference with the in-app override.
      isReducedMotion: () => systemReducedMotion || get().motion === 'reduce',
    }),
    {
      name: 'armory3d:v1',
      version: 1,
      partialize: (s) => ({
        favorites: s.favorites,
        audioOn: s.audioOn,
        propSpin: s.propSpin,
        shadows: s.shadows,
        showGrid: s.showGrid,
        quality: s.quality,
        motion: s.motion,
      }),
    }
  )
);
