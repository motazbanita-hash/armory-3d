// ── Layer manager ───────────────────────────────────────────────────────────
// Pure function: given a component group and the store state, decide how it should look.
// The model runtime applies the result to the actual three.js meshes every frame.

export const GHOST_OPACITY = 0.07;
export const XRAY_MAX = 0.85; // at xray = 1 a layer keeps 15% opacity

export function resolveLayerState(group, st) {
  const hidden = !!st.hidden[group];
  const selected = st.selectedGroup === group;
  const hovered = st.hoveredGroup === group && !selected;
  const isolating = st.isolate && !!st.selectedGroup;
  const ghost = isolating && !selected;

  let opacity = 1 - st.xray * XRAY_MAX;
  if (selected && st.xray > 0) opacity = 1; // keep the inspected component readable inside an X-ray
  if (ghost) opacity = GHOST_OPACITY;
  if (hidden) opacity = 0;

  return {
    hidden,
    selected,
    hovered,
    ghost,
    opacity,
    interactive: !hidden && !ghost && st.mode === 'inspection',
  };
}

// Emissive amber strength per highlight state.
export const HIGHLIGHT = { hover: 0.26, selected: 0.42, pulse: 0.12 };
