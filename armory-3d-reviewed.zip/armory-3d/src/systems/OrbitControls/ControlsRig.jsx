import { useEffect } from 'react';
import { OrbitControls } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useArmoryStore } from '../../store/useArmoryStore';
import { cameraRuntime } from '../CameraManager/cameraRuntime';

// What a primary drag does for each toolbar tool. Right-drag / two-finger gestures stay available.
const MOUSE = {
  rotate: { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN },
  pan: { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE },
  zoom: { LEFT: THREE.MOUSE.DOLLY, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN },
};
const TOUCH = {
  rotate: { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN },
  pan: { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_ROTATE },
  zoom: { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN },
};

/**
 * Orbit controls wired to the store.
 *  Desktop : left-drag rotate · wheel zoom · right-drag pan (the toolbar tool remaps left-drag)
 *  Touch   : one finger rotate · two fingers zoom + pan
 *  Cinematic mode keeps rotate only; Inspection unlocks zoom and pan.
 */
export default function ControlsRig() {
  const controls = useThree((s) => s.controls);
  const tool = useArmoryStore((s) => s.tool);
  const mode = useArmoryStore((s) => s.mode);

  useEffect(() => {
    if (!controls) return;
    controls.mouseButtons = MOUSE[tool] ?? MOUSE.rotate;
    controls.touches = TOUCH[tool] ?? TOUCH.rotate;
  }, [controls, tool]);

  useEffect(() => {
    if (!controls) return;
    controls.enableZoom = mode === 'inspection';
    controls.enablePan = mode === 'inspection';
  }, [controls, mode]);

  useFrame(() => {
    if (!controls) return;
    const st = useArmoryStore.getState();
    controls.autoRotate = st.autoRotate && !cameraRuntime.tweening;
    controls.autoRotateSpeed = st.mode === 'cinematic' ? 1.0 : 1.6;
  });

  return (
    <OrbitControls
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={2.2}
      maxDistance={16}
      rotateSpeed={0.8}
      zoomSpeed={0.9}
      panSpeed={0.8}
      screenSpacePanning
    />
  );
}
