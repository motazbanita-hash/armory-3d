import { useLayoutEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useArmoryStore } from '../../store/useArmoryStore';
import { damp } from '../../utils/math';
import { explodeFactor, explodeRuntime } from './explodeEngine';
import { HIGHLIGHT, resolveLayerState } from '../LayerManager/layerManager';

/**
 * One per-frame loop for a whole model (proxy or GLB).
 * `entriesRef.current` is a list of:
 *   { mesh, material, group, base: Vector3, explode: Vector3, delay, spin, baseRotY, opacity, emissive }
 *
 * It applies, in order:  explode offset → propeller spin → layer visibility / X-ray → highlight.
 * It reads the store with getState() so nothing re-renders React.
 */
export function useModelRuntime(entriesRef) {
  const spin = useRef({ angle: 0, speed: 0 });

  useLayoutEffect(() => {
    explodeRuntime.value = 0; // a freshly loaded product always starts assembled
  }, []);

  useFrame((state, dtRaw) => {
    const entries = entriesRef.current;
    if (!entries) return;
    const dt = Math.min(dtRaw, 0.1);
    const st = useArmoryStore.getState();
    const t = explodeRuntime.value;
    const time = state.clock.elapsedTime;
    const fade = 1 - Math.exp(-14 * dt);

    // Propellers spin only while assembled and not being inspected.
    const canSpin = st.propSpin && !st.isReducedMotion() && t < 0.02 && st.selectedGroup !== 'propellers';
    spin.current.speed = damp(spin.current.speed, canSpin ? 14 : 0, 3, dt);
    spin.current.angle += spin.current.speed * dt;

    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const L = resolveLayerState(e.group, st);

      // 1. explode
      const f = explodeFactor(e.delay, t);
      e.mesh.position.set(
        e.base.x + e.explode.x * f,
        e.base.y + e.explode.y * f,
        e.base.z + e.explode.z * f
      );

      // 2. propeller spin
      if (e.spin) e.mesh.rotation.y = e.baseRotY + spin.current.angle * e.spin;

      // 3. layers
      e.opacity += (L.opacity - e.opacity) * fade;
      if (Math.abs(e.opacity - L.opacity) < 0.003) e.opacity = L.opacity;

      // 4. highlight
      let em = 0;
      if (L.selected) em = HIGHLIGHT.selected + HIGHLIGHT.pulse * Math.sin(time * 3.2);
      else if (L.hovered) em = HIGHLIGHT.hover;
      e.emissive += (em - e.emissive) * fade;

      const m = e.material;
      m.opacity = e.opacity;
      m.transparent = e.opacity < 0.995;
      m.depthWrite = e.opacity > 0.5;
      m.emissiveIntensity = e.emissive;
      e.mesh.visible = e.opacity > 0.01;
      e.mesh.userData.interactive = L.interactive;
    }
  });
}
