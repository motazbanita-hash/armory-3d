import { useFrame } from '@react-three/fiber';
import { useArmoryStore } from '../../store/useArmoryStore';
import { clamp, damp, smoothstep } from '../../utils/math';

// ── Explode engine ──────────────────────────────────────────────────────────
// The slider writes a TARGET (0..1) to the store. This driver eases a shared runtime value
// toward it, and every part reads that value each frame. Per-part `delay` staggers the motion
// so outer pieces leave before inner ones, which keeps parts from sweeping through each other.

export const explodeRuntime = { value: 0 };

/** Eased 0..1 travel for a part that starts moving at `delay` (fraction of the slider). */
export function explodeFactor(delay, value = explodeRuntime.value) {
  const d = clamp(delay, 0, 0.9);
  return smoothstep((value - d) / (1 - d));
}

export function ExplodeDriver() {
  useFrame((_, dt) => {
    const st = useArmoryStore.getState();
    const target = st.explode;
    if (st.isReducedMotion()) {
      explodeRuntime.value = target;
      return;
    }
    const next = damp(explodeRuntime.value, target, 5, Math.min(dt, 0.1));
    explodeRuntime.value = Math.abs(next - target) < 0.0004 ? target : next;
  });
  return null;
}
