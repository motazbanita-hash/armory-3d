import * as THREE from 'three';

// Shared, non-reactive camera state (read inside frame loops).
export const cameraRuntime = { tweening: false };

const dir = (x, y, z) => new THREE.Vector3(x, y, z).normalize();

// Directions FROM the model TO the camera. The model's front is +X, its left is -Z.
export const PRESET_DIRS = {
  default: dir(0.62, 0.36, 0.78),
  front: dir(1, 0.1, 0),
  rear: dir(-1, 0.1, 0),
  left: dir(0, 0.1, -1),
  right: dir(0, 0.1, 1),
  top: dir(0.0001, 1, 0.0001),
  bottom: dir(0.0001, -1, 0.0001),
};

export const CAMERA_PRESETS = [
  { id: 'default', label: 'Default' },
  { id: 'front', label: 'Front' },
  { id: 'rear', label: 'Rear' },
  { id: 'left', label: 'Left' },
  { id: 'right', label: 'Right' },
  { id: 'top', label: 'Top' },
  { id: 'bottom', label: 'Bottom' },
];
