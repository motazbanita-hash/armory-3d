import { useCallback, useEffect, useRef } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import gsap from 'gsap';
import { useArmoryStore } from '../../store/useArmoryStore';
import { clamp, fitDistance } from '../../utils/math';
import { PRESET_DIRS, cameraRuntime } from './cameraRuntime';

const UP = new THREE.Vector3(0, 1, 0);

/**
 * Camera manager: cinematic intro when a product loads, preset views, zoom buttons and reset.
 * All moves are arcs around the target (spherical interpolation), so going Front → Rear
 * orbits the model instead of cutting through it.
 */
export default function CameraRig() {
  const camera = useThree((s) => s.camera);
  const controls = useThree((s) => s.controls);
  const size = useThree((s) => s.size);
  const bounds = useArmoryStore((s) => s.bounds);
  const cmd = useArmoryStore((s) => s.cameraCmd);

  const tween = useRef(null);
  const sizeRef = useRef(size);
  sizeRef.current = size;
  const firstIntro = useRef(true);

  const stop = useCallback(() => {
    tween.current?.kill();
    tween.current = null;
    cameraRuntime.tweening = false;
  }, []);

  // Pose (position + target) for a named preset at the current bounds / aspect ratio.
  const poseFor = useCallback(
    (name) => {
      const b = useArmoryStore.getState().bounds;
      if (!b) return null;
      const { width, height } = sizeRef.current;
      const dist = fitDistance(b.radius, camera.fov, width / Math.max(height, 1));
      const target = new THREE.Vector3(0, b.targetY, 0);
      const position = target.clone().addScaledVector(PRESET_DIRS[name] ?? PRESET_DIRS.default, dist);
      return { position, target };
    },
    [camera]
  );

  const flyTo = useCallback(
    (toPos, toTarget, duration, fromOffset) => {
      if (!controls) return;
      stop();
      const fromTarget = controls.target.clone();
      const startOffset = fromOffset ?? camera.position.clone().sub(fromTarget);
      const endOffset = toPos.clone().sub(toTarget);
      const fromLen = startOffset.length();
      const toLen = endOffset.length();
      const startDir = startOffset.clone().normalize();
      const q = new THREE.Quaternion().setFromUnitVectors(startDir, endOffset.clone().normalize());
      const qi = new THREE.Quaternion();
      const qp = new THREE.Quaternion();
      const v = new THREE.Vector3();

      const apply = (p) => {
        qp.copy(qi).slerp(q, p);
        v.copy(startDir).applyQuaternion(qp);
        controls.target.lerpVectors(fromTarget, toTarget, p);
        camera.position.copy(controls.target).addScaledVector(v, fromLen + (toLen - fromLen) * p);
        camera.up.copy(UP);
        controls.update();
      };

      if (duration <= 0) {
        apply(1);
        return;
      }
      const state = { p: 0 };
      cameraRuntime.tweening = true;
      tween.current = gsap.to(state, {
        p: 1,
        duration,
        ease: 'power3.inOut',
        onUpdate: () => apply(state.p),
        onComplete: () => {
          cameraRuntime.tweening = false;
        },
      });
    },
    [camera, controls, stop]
  );

  // User grabs the camera → cancel any scripted move so they stay in control.
  useEffect(() => {
    if (!controls) return undefined;
    controls.addEventListener('start', stop);
    return () => {
      controls.removeEventListener('start', stop);
      stop();
    };
  }, [controls, stop]);

  // Cinematic intro whenever a product's model reports new bounds.
  useEffect(() => {
    if (!controls || !bounds) return;
    const st = useArmoryStore.getState();
    const end = poseFor('default');
    if (!end) return;
    const reduced = st.isReducedMotion();
    const duration = reduced ? 0 : firstIntro.current ? 2.4 : st.mode === 'cinematic' ? 1.9 : 1.0;
    firstIntro.current = false;

    controls.target.copy(end.target);
    const endOffset = end.position.clone().sub(end.target);
    const startOffset = endOffset
      .clone()
      .applyAxisAngle(UP, 1.05)
      .setLength(endOffset.length() * 1.75);
    startOffset.y += endOffset.length() * 0.25;
    camera.position.copy(end.target).add(startOffset);
    controls.update();
    flyTo(end.position, end.target, duration, startOffset);
  }, [bounds, controls, camera, poseFor, flyTo]);

  // Commands from the UI: presets, zoom in/out, reset.
  useEffect(() => {
    if (!cmd || !controls) return;
    const reduced = useArmoryStore.getState().isReducedMotion();
    if (cmd.type === 'preset') {
      const pose = poseFor(cmd.value);
      if (pose) flyTo(pose.position, pose.target, reduced ? 0 : 0.95);
    } else if (cmd.type === 'zoom') {
      const offset = camera.position.clone().sub(controls.target);
      const len = clamp(offset.length() * (cmd.value > 0 ? 0.74 : 1.35), controls.minDistance, controls.maxDistance);
      const target = controls.target.clone();
      flyTo(target.clone().addScaledVector(offset.normalize(), len), target, reduced ? 0 : 0.35);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cmd]);

  return null;
}
