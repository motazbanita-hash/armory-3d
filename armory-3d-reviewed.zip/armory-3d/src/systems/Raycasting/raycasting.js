import * as THREE from 'three';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';

// ── Raycasting system ───────────────────────────────────────────────────────
// Selection uses React-Three-Fiber's built-in three.js Raycaster. Each part mesh carries
// userData.group (its component group id). Two things live here:
//   1. a raycast "gate" so hidden / ghosted / non-inspection meshes can't be hit
//   2. shared pointer handlers that turn a hit mesh into a store selection

const meshRaycast = THREE.Mesh.prototype.raycast;

function gatedRaycast(raycaster, intersects) {
  if (!this.userData.interactive) return; // hidden, ghosted (isolate) or in cinematic mode
  meshRaycast.call(this, raycaster, intersects);
}

export function installRaycastGate(mesh) {
  mesh.userData.interactive = true;
  mesh.raycast = gatedRaycast;
}

const groupOf = (e) => e.object?.userData?.group;

export const groupHandlers = {
  onPointerOver: (e) => {
    const group = groupOf(e);
    if (!group) return;
    e.stopPropagation();
    useArmoryStore.getState().setHover(group);
    document.body.style.cursor = 'pointer';
  },
  onPointerOut: (e) => {
    const group = groupOf(e);
    const st = useArmoryStore.getState();
    if (group && st.hoveredGroup === group) st.setHover(null);
    document.body.style.cursor = '';
  },
  onClick: (e) => {
    const group = groupOf(e);
    if (!group) return;
    e.stopPropagation();
    if (e.delta > 4) return; // it was a drag (orbit), not a click
    useArmoryStore.getState().selectGroup(group);
    sfx('select');
  },
};
