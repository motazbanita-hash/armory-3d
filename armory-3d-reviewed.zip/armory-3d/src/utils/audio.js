import { useArmoryStore } from '../store/useArmoryStore';

// Tiny synthesized UI sounds (no audio files). Off by default; toggled in the nav / settings.
let ctx = null;

function getCtx() {
  if (ctx) {
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  const AC = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext);
  if (!AC) return null;
  ctx = new AC();
  return ctx;
}

function tone(c, { from, to = from, dur = 0.08, type = 'square', vol = 0.025, delay = 0 }) {
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(from, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(to, 1), t0 + dur);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

const SOUNDS = {
  click: [{ from: 620, to: 520, dur: 0.05 }],
  select: [
    { from: 420, to: 520, dur: 0.07 },
    { from: 760, to: 840, dur: 0.09, delay: 0.06 },
  ],
  product: [
    { from: 180, to: 320, dur: 0.16, type: 'sawtooth', vol: 0.02 },
    { from: 640, to: 900, dur: 0.12, delay: 0.1 },
  ],
  mode: [
    { from: 300, to: 600, dur: 0.12, type: 'triangle', vol: 0.04 },
    { from: 900, to: 1200, dur: 0.1, type: 'triangle', delay: 0.1, vol: 0.03 },
  ],
  back: [{ from: 520, to: 300, dur: 0.08 }],
};

export function sfx(name = 'click') {
  if (!useArmoryStore.getState().audioOn) return;
  const c = getCtx();
  const def = SOUNDS[name];
  if (!c || !def) return;
  def.forEach((t) => tone(c, t));
}
