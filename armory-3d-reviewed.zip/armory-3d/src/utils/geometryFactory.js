import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

/**
 * Two-blade propeller: [halfLength, chord, thickness].
 * Blades are slightly pitched in opposite directions and joined by a small hub.
 */
function createProp([half, chord, thick]) {
  const make = (offset, pitch) => {
    const g = new THREE.BoxGeometry(half, thick, chord);
    g.rotateX(pitch);
    g.translate(offset, 0, 0);
    return g;
  };
  const hub = new THREE.CylinderGeometry(chord * 0.55, chord * 0.55, thick * 4, 16);
  const merged = mergeGeometries([make(half / 2, 0.28), make(-half / 2, -0.28), hub], false);
  merged.computeBoundingBox();
  merged.computeBoundingSphere();
  return merged;
}

const BUILDERS = {
  box: (a) => new THREE.BoxGeometry(...a),
  rbox: (a) => new RoundedBoxGeometry(...a), // [w, h, d, segments, radius]
  cyl: (a) => new THREE.CylinderGeometry(...a), // [rTop, rBottom, height, radialSegments]
  sphere: (a) => new THREE.SphereGeometry(...a), // [radius, wSeg, hSeg]
  torus: (a) => new THREE.TorusGeometry(...a), // [radius, tube, radialSeg, tubularSeg]
  capsule: (a) => new THREE.CapsuleGeometry(...a), // [radius, length, capSeg, radialSeg]
  prop: createProp,
};

export function createGeometry(shape, args) {
  const build = BUILDERS[shape];
  if (!build) throw new Error(`Unknown part shape "${shape}"`);
  return build(args);
}

/** Dispose every geometry / material in the given collections. */
export function disposeAll(...collections) {
  collections.flat().forEach((item) => item?.dispose?.());
}
