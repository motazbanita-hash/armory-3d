// Pure helpers for describing proxy models as data (no three.js import on purpose,
// so model specs can be tested / edited without a 3D runtime).
//
// Conventions
//  - Model front is +X, up is +Y.
//  - polar(r, a, y) -> point at radius r, angle a (radians, from +X toward +Z), height y.
//  - Every part is ONE mesh. A "component group" (Propellers, Motors, ...) is just
//    the set of parts that share the same `group` id.

export const deg = (d) => (d * Math.PI) / 180;

export const polar = (r, a, y = 0) => [Math.cos(a) * r, y, Math.sin(a) * r];

/**
 * A cylindrical strut whose TOP end sits at (topR, topY) and BOTTOM end at (botR, botY),
 * both on the radial line of angle `a`. Returns position / rotation / length for a
 * CylinderGeometry (axis = Y). Rotation uses Euler order 'YXZ'.
 */
export function strut(a, topR, topY, botR, botY) {
  const h = botR - topR;
  const v = topY - botY;
  const length = Math.hypot(h, v);
  const tilt = Math.atan2(h, v);
  return {
    length,
    pos: polar((topR + botR) / 2, a, (topY + botY) / 2),
    rot: [0, Math.PI - a, -tilt, 'YXZ'],
  };
}

/**
 * Build a part description.
 * @param {string} id      unique id inside the model
 * @param {string} group   component group id (see data/components.js)
 * @param {string} shape   box | rbox | cyl | sphere | torus | capsule | prop
 * @param {number[]} args  constructor args for the shape (see utils/geometryFactory.js)
 * @param {string} mat     key in the model's `materials`
 * @param {object} o       { pos, rot, scale, explode, delay, spin }
 *   explode : offset (model units) the part travels at 100% explode
 *   delay   : 0..0.9 — fraction of the slider at which the part starts moving (staging)
 *   spin    : propeller spin direction (1 / -1), 0 = static
 */
export function part(id, group, shape, args, mat, o = {}) {
  return {
    id,
    group,
    shape,
    args,
    mat,
    pos: [0, 0, 0],
    rot: [0, 0, 0],
    scale: [1, 1, 1],
    explode: [0, 0, 0],
    delay: 0,
    spin: 0,
    ...o,
  };
}

export const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
