export const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));
export const smoothstep = (t) => {
  const x = clamp(t);
  return x * x * (3 - 2 * x);
};
export const damp = (current, target, lambda, dt) => current + (target - current) * (1 - Math.exp(-lambda * dt));
export const cx = (...a) => a.filter(Boolean).join(' ');

/** Camera distance that fits a sphere of `radius` for a vertical fov (deg) and aspect ratio. */
export function fitDistance(radius, fovDeg, aspect, padding = 1.12) {
  const half = (fovDeg * Math.PI) / 360;
  const limiting = Math.atan(Math.tan(half) * Math.min(1, aspect));
  return (radius / Math.sin(limiting)) * padding;
}
