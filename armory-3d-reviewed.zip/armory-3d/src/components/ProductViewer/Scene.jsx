import { Suspense } from 'react';
import { GizmoHelper, GizmoViewport } from '@react-three/drei';
import { getProduct } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { ExplodeDriver } from '../../systems/ExplodeEngine/explodeEngine';
import ControlsRig from '../../systems/OrbitControls/ControlsRig';
import CameraRig from '../../systems/CameraManager/CameraRig';
import ProductModel from './ProductModel';
import Stage, { Studio } from './Stage';

export default function Scene({ lowQuality, compact }) {
  const productId = useArmoryStore((s) => s.productId);
  const product = getProduct(productId);

  return (
    <>
      <color attach="background" args={['#111519']} />
      <fog attach="fog" args={['#111519', 14, 30]} />

      <ambientLight intensity={0.3} />
      <hemisphereLight args={['#aab6bd', '#171D21', 0.45]} />
      <directionalLight position={[4, 7, 5]} intensity={2.1} color="#fff4e6" />
      <directionalLight position={[-6, 3, -4]} intensity={0.9} color="#C3A36A" />
      <Studio />

      <Stage lowQuality={lowQuality} />

      <Suspense fallback={null}>
        {/* key => a full remount (fresh geometry, intro animation, new bounds) per product */}
        <ProductModel key={product.id} product={product} />
      </Suspense>

      <ExplodeDriver />
      <ControlsRig />
      <CameraRig />

      {/* camera orientation indicator — click an axis to snap the view */}
      <GizmoHelper alignment="bottom-right" margin={compact ? [48, 48] : [70, 150]}>
        <GizmoViewport
          axisColors={['#C3A36A', '#8F774B', '#929DA3']}
          labelColor="#111519"
          hideNegativeAxes
          axisHeadScale={0.9}
        />
      </GizmoHelper>
    </>
  );
}
