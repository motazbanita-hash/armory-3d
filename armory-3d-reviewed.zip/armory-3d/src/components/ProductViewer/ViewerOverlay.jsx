import { ChevronLeft, ChevronRight, Film, Heart, Maximize, Minimize, Scan, X } from 'lucide-react';
import { getProduct, productsInCategory } from '../../data/products';
import { getComponentInfo } from '../../data/components';
import { useArmoryStore } from '../../store/useArmoryStore';
import { useFullscreen } from '../../hooks/useFullscreen';
import { useMediaQuery } from '../../hooks/useMediaQuery';
import { useSwipe } from '../../hooks/useSwipe';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';
import Segmented from '../ui/Segmented';

const MODES = [
  { id: 'cinematic', label: 'Cinematic', icon: Film },
  { id: 'inspection', label: 'Inspection', icon: Scan },
];

/** HTML layer on top of the canvas: mode toggle, product title/arrows, selection chip, hints. */
export default function ViewerOverlay({ compact }) {
  const productId = useArmoryStore((s) => s.productId);
  const category = useArmoryStore((s) => s.category);
  const mode = useArmoryStore((s) => s.mode);
  const selectedGroup = useArmoryStore((s) => s.selectedGroup);
  const bounds = useArmoryStore((s) => s.bounds);
  const favorites = useArmoryStore((s) => s.favorites);
  const setMode = useArmoryStore((s) => s.setMode);
  const stepProduct = useArmoryStore((s) => s.stepProduct);
  const selectGroup = useArmoryStore((s) => s.selectGroup);
  const toggleFavorite = useArmoryStore((s) => s.toggleFavorite);
  const { focus, toggle } = useFullscreen();
  const coarse = useMediaQuery('(pointer: coarse)');

  const product = getProduct(productId);
  const list = productsInCategory(category);
  const index = Math.max(0, list.findIndex((p) => p.id === productId));
  const isFav = favorites.includes(productId);
  const step = (dir) => {
    stepProduct(dir);
    sfx('product');
  };
  const swipe = useSwipe(step);

  const hint =
    mode === 'cinematic'
      ? 'CINEMATIC PREVIEW — SWITCH TO INSPECTION FOR FULL CONTROL'
      : coarse
        ? 'ONE FINGER ROTATE · PINCH ZOOM · TWO-FINGER PAN · TAP A PART'
        : 'DRAG ROTATE · SCROLL ZOOM · RIGHT-DRAG PAN · CLICK A PART';

  return (
    <div className="viewer__overlay">
      <div className="viewer__top">
        <Segmented
          options={MODES}
          value={mode}
          onChange={setMode}
          ariaLabel="Viewing mode"
          className="viewer__modes"
        />

        <div className="vtitle" {...swipe}>
          <IconButton icon={ChevronLeft} label="Previous product" onClick={() => step(-1)} sound={null} />
          <div className="vtitle__text" aria-live="polite">
            <span className="vtitle__id">{product.identifier}</span>
            <strong>{product.name}</strong>
            <span className="vtitle__count">
              {String(index + 1).padStart(2, '0')} / {String(list.length).padStart(2, '0')}
            </span>
          </div>
          <IconButton icon={ChevronRight} label="Next product" onClick={() => step(1)} sound={null} />
        </div>

        <div className="viewer__actions">
          <IconButton
            icon={Heart}
            label={isFav ? 'Remove from favorites' : 'Add to favorites'}
            active={isFav}
            onClick={() => toggleFavorite(productId)}
            className="fav"
          />
          <IconButton
            icon={focus ? Minimize : Maximize}
            label={focus ? 'Exit fullscreen inspection' : 'Fullscreen inspection'}
            active={focus}
            onClick={toggle}
          />
        </div>
      </div>

      {selectedGroup && mode === 'inspection' && (
        <div className="chip chip--selected">
          <span className="chip__dot" />
          <span>SELECTED · {getComponentInfo(selectedGroup).label.toUpperCase()}</span>
          <button type="button" aria-label="Deselect component" onClick={() => selectGroup(null)}>
            <X size={14} />
          </button>
        </div>
      )}

      {!compact && (
        <figure className="refcard">
          <img src={product.image} alt={`${product.identifier} reference`} />
          <figcaption>REFERENCE</figcaption>
        </figure>
      )}

      <div className={cx('viewer__hint', compact && 'viewer__hint--compact')}>
        <span>{hint}</span>
        <span className="viewer__proxy">VISUAL PROXY MODEL — NOT DIMENSIONALLY ACCURATE</span>
      </div>

      {!bounds && (
        <div className="viewer__loading" role="status">
          <span className="spinner" /> LOADING MODEL
        </div>
      )}
    </div>
  );
}
