import { ContactShadows, Environment, Grid, Lightformer } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import { useArmoryStore } from '../../store/useArmoryStore';

const PLATFORM_R = 3.7;

/** Procedural studio lighting — no HDR download needed, so it works offline. */
export function Studio() {
  return (
    <Environment resolution={256} frames={1}>
      <Lightformer form="rect" intensity={3} position={[0, 6, 0]} rotation-x={Math.PI / 2} scale={[14, 14, 1]} />
      <Lightformer form="rect" intensity={2.2} position={[-7, 2.5, 1]} rotation-y={Math.PI / 2} scale={[12, 4, 1]} />
      <Lightformer
        form="rect"
        intensity={1.6}
        position={[7, 2, -3]}
        rotation-y={-Math.PI / 2}
        scale={[10, 3, 1]}
        color="#C3A36A"
      />
      <Lightformer form="rect" intensity={1.2} position={[0, 2, 8]} rotation-y={Math.PI} scale={[10, 3, 1]} />
      <Lightformer form="ring" intensity={1.4} position={[0, 4, -6]} scale={5} color="#dde3e5" />
    </Environment>
  );
}

/** Ground platform, technical grid, ring markings and soft contact shadows. */
export default function Stage({ lowQuality }) {
  const showGrid = useArmoryStore((s) => s.showGrid);
  const shadows = useArmoryStore((s) => s.shadows);
  const platform = useRef(null);
  const ringMat = useRef(null);

  // Looking from below (Bottom preset) the platform fades out so the underside stays visible.
  useFrame(({ camera }) => {
    const below = camera.position.y < 0.05;
    const target = below ? 0.12 : 1;
    if (platform.current) {
      const m = platform.current.material;
      m.opacity += (target - m.opacity) * 0.15;
      m.transparent = m.opacity < 0.99;
    }
    if (ringMat.current) ringMat.current.opacity += ((below ? 0.1 : 0.55) - ringMat.current.opacity) * 0.15;
  });

  return (
    <group>
      <mesh ref={platform} position={[0, -0.06, 0]} receiveShadow>
        <cylinderGeometry args={[PLATFORM_R, PLATFORM_R + 0.12, 0.12, 72]} />
        <meshStandardMaterial color="#171D21" roughness={0.85} metalness={0.25} />
      </mesh>

      <mesh rotation-x={-Math.PI / 2} position={[0, 0.003, 0]}>
        <ringGeometry args={[PLATFORM_R - 0.16, PLATFORM_R - 0.12, 120]} />
        <meshBasicMaterial ref={ringMat} color="#C3A36A" transparent opacity={0.55} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.003, 0]}>
        <ringGeometry args={[1.9, 1.92, 96]} />
        <meshBasicMaterial color="#8F774B" transparent opacity={0.4} />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[Math.cos((i * Math.PI) / 2) * (PLATFORM_R - 0.14), 0.004, Math.sin((i * Math.PI) / 2) * (PLATFORM_R - 0.14)]} rotation-x={-Math.PI / 2} rotation-z={(i * Math.PI) / 2}>
          <planeGeometry args={[0.3, 0.03]} />
          <meshBasicMaterial color="#C3A36A" />
        </mesh>
      ))}

      {showGrid && (
        <Grid
          position={[0, 0.006, 0]}
          args={[30, 30]}
          cellSize={0.5}
          cellThickness={0.5}
          cellColor="#303A40"
          sectionSize={2.5}
          sectionThickness={0.9}
          sectionColor="#8F774B"
          fadeDistance={15}
          fadeStrength={2}
          infiniteGrid
        />
      )}

      {shadows && (
        <ContactShadows
          position={[0, 0.012, 0]}
          opacity={0.55}
          scale={9}
          blur={2.4}
          far={3.2}
          resolution={lowQuality ? 256 : 512}
          color="#000000"
        />
      )}
    </group>
  );
}
