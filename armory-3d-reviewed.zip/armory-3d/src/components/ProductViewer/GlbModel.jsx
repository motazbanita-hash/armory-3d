import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useGLTF } from '@react-three/drei';
import { groupHandlers, installRaycastGate } from '../../systems/Raycasting/raycasting';
import { useModelRuntime } from '../../systems/ExplodeEngine/useModelRuntime';
import { useArmoryStore } from '../../store/useArmoryStore';
import { AMBER, TARGET_SPAN } from './ProxyModel';

/**
 * Optional real model. Enabled by setting `model.glb` on a product (e.g. '/models/quadcopter-01/model.glb').
 *
 * Authoring convention (so raycasting / layers / explode work on a GLB):
 *   • name each mesh  "<groupId>__anything"   e.g. "propellers__prop_front_left"
 *     (groupId = one of the product's `components`; unnamed meshes fall into "body")
 *   • export with applied transforms and a flat hierarchy, front of the model toward +X.
 * Exploded directions are derived automatically (away from the model centre).
 */
export default function GlbModel({ url, groupIds }) {
  const gltf = useGLTF(url);
  const scene = useMemo(() => gltf.scene.clone(true), [gltf]);
  const enterRef = useRef(null);
  const fitRef = useRef(null);
  const entriesRef = useRef(null);

  useLayoutEffect(() => {
    const fit = fitRef.current;
    fit.scale.setScalar(1);
    fit.position.set(0, 0, 0);
    fit.updateMatrixWorld(true);

    const box = new THREE.Box3().setFromObject(fit, true);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());

    const entries = [];
    fit.traverse((o) => {
      if (!o.isMesh) return;
      const mat = Array.isArray(o.material) ? o.material[0] : o.material;
      o.material = mat.clone();
      o.material.emissive = new THREE.Color(AMBER);
      o.material.emissiveIntensity = 0;
      const prefix = o.name.includes('__') ? o.name.split('__')[0] : 'body';
      const group = groupIds.includes(prefix) ? prefix : 'body';
      o.userData.group = group;
      installRaycastGate(o);

      const c = new THREE.Box3().setFromObject(o).getCenter(new THREE.Vector3());
      const dir = c.sub(center);
      dir.y += 0.15;
      dir.normalize().multiplyScalar(1.2);
      entries.push({
        mesh: o,
        material: o.material,
        group,
        base: o.position.clone(),
        explode: dir,
        delay: 0,
        spin: 0,
        baseRotY: o.rotation.y,
        opacity: 1,
        emissive: 0,
      });
    });
    entriesRef.current = entries;

    const s = TARGET_SPAN / Math.max(size.x, size.z);
    fit.scale.setScalar(s);
    fit.position.set(-center.x * s, 0.5 - box.min.y * s, -center.z * s);
    const height = size.y * s;
    useArmoryStore.getState().setBounds({
      radius: Math.hypot((size.x * s) / 2, height / 2, (size.z * s) / 2),
      height,
      targetY: 0.5 + height / 2,
    });
  }, [scene, groupIds]);

  useEffect(
    () => () =>
      scene.traverse((o) => {
        if (o.isMesh) o.material?.dispose?.();
      }),
    [scene]
  );

  useModelRuntime(entriesRef);

  return (
    <group ref={enterRef}>
      <group ref={fitRef}>
        <primitive object={scene} {...groupHandlers} />
      </group>
    </group>
  );
}
