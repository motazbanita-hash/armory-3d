/** Shown instead of the canvas if WebGL is unavailable or the 3D scene crashes. */
export function ViewerFallback({ product, onRetry }) {
  return (
    <div className="viewer-fallback" role="alert">
      <img src={product.image} alt={product.name} />
      <h3>3D viewer unavailable</h3>
      <p>Your browser could not start WebGL, or the scene failed to load. The product browser still works.</p>
      {onRetry && (
        <button type="button" className="btn" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

/** Shown for categories that have no equipment yet. */
export function EmptyCategory({ category }) {
  return (
    <div className="viewer-empty">
      <span className="eyebrow">CATEGORY OFFLINE</span>
      <h3>{category.label}</h3>
      <p>No equipment has been loaded into this category yet. The catalog architecture is ready — products can be added in <code>src/data/products.js</code>.</p>
    </div>
  );
}
