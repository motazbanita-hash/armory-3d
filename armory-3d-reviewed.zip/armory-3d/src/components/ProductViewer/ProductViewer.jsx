import { useMemo, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { PerformanceMonitor } from '@react-three/drei';
import { getProduct, productsInCategory } from '../../data/products';
import { getCategory } from '../../data/categories';
import { useArmoryStore } from '../../store/useArmoryStore';
import ErrorBoundary from '../ui/ErrorBoundary';
import Scene from './Scene';
import ViewerOverlay from './ViewerOverlay';
import { EmptyCategory, ViewerFallback } from './ViewerFallback';

function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

/** Reusable 3D viewer: canvas + overlay. Reads everything it needs from the store. */
export default function ProductViewer({ compact = false }) {
  const productId = useArmoryStore((s) => s.productId);
  const category = useArmoryStore((s) => s.category);
  const quality = useArmoryStore((s) => s.quality);
  const [maxDpr, setMaxDpr] = useState(compact ? 1.5 : 2);
  const [retry, setRetry] = useState(0);
  const supported = useMemo(webglAvailable, []);

  const product = getProduct(productId);
  const low = quality === 'low';

  if (productsInCategory(category).length === 0) {
    return (
      <div className="viewer">
        <EmptyCategory category={getCategory(category)} />
      </div>
    );
  }

  const fallback = (
    <ViewerFallback product={product} onRetry={supported ? () => setRetry((n) => n + 1) : undefined} />
  );

  return (
    <div className="viewer">
      {supported ? (
        <ErrorBoundary key={retry} fallback={fallback}>
          <Canvas
            className="viewer__canvas"
            dpr={[1, low ? 1 : maxDpr]}
            camera={{ fov: 38, near: 0.1, far: 80, position: [6, 3.4, 7.5] }}
            gl={{ antialias: true, powerPreference: 'high-performance' }}
            onPointerMissed={() => {
              const st = useArmoryStore.getState();
              if (st.selectedGroup) st.selectGroup(null);
            }}
          >
            <PerformanceMonitor onDecline={() => setMaxDpr(1)} />
            <Scene lowQuality={low || compact} compact={compact} />
          </Canvas>
        </ErrorBoundary>
      ) : (
        fallback
      )}
      <div className="viewer__vignette" aria-hidden="true" />
      <ViewerOverlay compact={compact} />
    </div>
  );
}
