import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import gsap from 'gsap';
import { createGeometry, disposeAll } from '../../utils/geometryFactory';
import { groupHandlers, installRaycastGate } from '../../systems/Raycasting/raycasting';
import { useModelRuntime } from '../../systems/ExplodeEngine/useModelRuntime';
import { useArmoryStore } from '../../store/useArmoryStore';

export const TARGET_SPAN = 3.6; // every model is scaled so its widest horizontal extent equals this
export const AMBER = '#C3A36A';

/**
 * Renders a data-driven proxy model (see data/models/*). Every part is its own mesh, which is what
 * makes raycasting, exploding and layers work per component.
 */
export default function ProxyModel({ spec }) {
  const enterRef = useRef(null);
  const fitRef = useRef(null);
  const meshRefs = useRef([]);
  const entriesRef = useRef(null);

  const geometries = useMemo(() => spec.parts.map((p) => createGeometry(p.shape, p.args)), [spec]);
  const materials = useMemo(() => {
    const map = {};
    spec.parts.forEach((p) => {
      const key = `${p.group}:${p.mat}`; // one material per (group, look) so highlights stay per component
      if (!map[key]) {
        map[key] = new THREE.MeshPhysicalMaterial({
          ...spec.materials[p.mat],
          emissive: new THREE.Color(AMBER),
          emissiveIntensity: 0,
        });
      }
    });
    return map;
  }, [spec]);
  const userData = useMemo(() => spec.parts.map((p) => ({ group: p.group })), [spec]);

  useEffect(() => () => disposeAll(geometries, Object.values(materials)), [geometries, materials]);

  // Auto-centre + auto-scale, build the runtime entry list, report bounds to the camera.
  useLayoutEffect(() => {
    const fit = fitRef.current;
    fit.scale.setScalar(1);
    fit.position.set(0, 0, 0);
    fit.updateMatrixWorld(true);

    const box = new THREE.Box3().setFromObject(fit, true);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const s = TARGET_SPAN / Math.max(size.x, size.z);
    fit.scale.setScalar(s);
    fit.position.set(-center.x * s, spec.hover - box.min.y * s, -center.z * s);

    entriesRef.current = spec.parts.map((p, i) => {
      const mesh = meshRefs.current[i];
      installRaycastGate(mesh);
      return {
        mesh,
        material: mesh.material,
        group: p.group,
        base: new THREE.Vector3(...p.pos),
        explode: new THREE.Vector3(...p.explode),
        delay: p.delay,
        spin: p.spin,
        baseRotY: p.rot[1],
        opacity: 1,
        emissive: 0,
      };
    });

    const height = size.y * s;
    useArmoryStore.getState().setBounds({
      radius: Math.hypot((size.x * s) / 2, height / 2, (size.z * s) / 2),
      height,
      targetY: spec.hover + height / 2,
    });
  }, [spec]);

  // Product entrance (scale / yaw / drop). Skipped for reduced motion.
  useEffect(() => {
    if (useArmoryStore.getState().isReducedMotion()) return undefined;
    const g = enterRef.current;
    const tweens = [
      gsap.fromTo(g.scale, { x: 0.82, y: 0.82, z: 0.82 }, { x: 1, y: 1, z: 1, duration: 1.1, ease: 'power3.out' }),
      gsap.fromTo(g.rotation, { y: -0.9 }, { y: 0, duration: 1.4, ease: 'power3.out' }),
      gsap.fromTo(g.position, { y: 0.35 }, { y: 0, duration: 1.1, ease: 'power3.out' }),
    ];
    return () => tweens.forEach((t) => t.kill());
  }, []);

  useModelRuntime(entriesRef);

  return (
    <group ref={enterRef}>
      <group ref={fitRef}>
        {spec.parts.map((p, i) => (
          <mesh
            key={p.id}
            ref={(el) => {
              meshRefs.current[i] = el;
            }}
            geometry={geometries[i]}
            material={materials[`${p.group}:${p.mat}`]}
            position={p.pos}
            rotation={p.rot}
            scale={p.scale}
            userData={userData[i]}
            {...groupHandlers}
          />
        ))}
      </group>
    </group>
  );
}
