import { Suspense, useEffect, useState } from 'react';
import { getModelSpec } from '../../data/models';
import ErrorBoundary from '../ui/ErrorBoundary';
import ProxyModel from './ProxyModel';
import GlbModel from './GlbModel';

// A GLB URL is "available" only if it exists AND is not the SPA's index.html fallback.
function useAssetAvailable(url) {
  const [ok, setOk] = useState(null); // null = checking
  useEffect(() => {
    if (!url) {
      setOk(false);
      return undefined;
    }
    let live = true;
    fetch(url, { method: 'HEAD' })
      .then((r) => live && setOk(r.ok && !(r.headers.get('content-type') || '').includes('text/html')))
      .catch(() => live && setOk(false));
    return () => {
      live = false;
    };
  }, [url]);
  return ok;
}

/**
 * Chooses the real GLB when one is configured and loadable, otherwise the visual proxy model.
 * Any GLB failure silently falls back to the proxy, so the viewer always works.
 */
export default function ProductModel({ product }) {
  const spec = getModelSpec(product.model.id);
  const glb = product.model.glb;
  const available = useAssetAvailable(glb);
  const proxy = <ProxyModel key={`${product.id}-proxy`} spec={spec} />;

  if (glb && available) {
    return (
      <ErrorBoundary fallback={proxy}>
        <Suspense fallback={proxy}>
          <GlbModel key={`${product.id}-glb`} url={glb} groupIds={product.components} />
        </Suspense>
      </ErrorBoundary>
    );
  }
  return proxy;
}
