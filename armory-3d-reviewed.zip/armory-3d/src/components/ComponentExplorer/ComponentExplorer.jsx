import { Eye, EyeOff, Focus, X } from 'lucide-react';
import { getComponentInfo, getProductGroups } from '../../data/components';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';

/** Interactive component list — hover, selection and visibility are shared with the 3D scene. */
export function ComponentExplorer({ product }) {
  const selected = useArmoryStore((s) => s.selectedGroup);
  const hovered = useArmoryStore((s) => s.hoveredGroup);
  const hidden = useArmoryStore((s) => s.hidden);
  const selectGroup = useArmoryStore((s) => s.selectGroup);
  const setHover = useArmoryStore((s) => s.setHover);
  const groups = getProductGroups(product);

  return (
    <ul className="complist" aria-label="Components">
      {groups.map((g, i) => (
        <li key={g.id}>
          <button
            type="button"
            className={cx('comp', selected === g.id && 'is-selected', hovered === g.id && 'is-hover', hidden[g.id] && 'is-hidden')}
            aria-pressed={selected === g.id}
            onMouseEnter={() => setHover(g.id)}
            onMouseLeave={() => setHover(null)}
            onFocus={() => setHover(g.id)}
            onBlur={() => setHover(null)}
            onClick={() => {
              sfx('select');
              selectGroup(selected === g.id ? null : g.id);
            }}
          >
            <span className="comp__n">{String(i + 1).padStart(2, '0')}</span>
            <span className="comp__label">
              <strong>{g.label}</strong>
              <small>
                {g.role} · {g.count} {g.count === 1 ? 'part' : 'parts'}
              </small>
            </span>
            {hidden[g.id] && <EyeOff size={14} aria-label="Hidden" />}
          </button>
        </li>
      ))}
    </ul>
  );
}

/** Details of the selected component (general educational description — not product specs). */
export function ComponentDetail() {
  const selected = useArmoryStore((s) => s.selectedGroup);
  const hidden = useArmoryStore((s) => s.hidden);
  const isolate = useArmoryStore((s) => s.isolate);
  const selectGroup = useArmoryStore((s) => s.selectGroup);
  const toggleHidden = useArmoryStore((s) => s.toggleHidden);
  const toggleIsolate = useArmoryStore((s) => s.toggleIsolate);

  if (!selected) {
    return (
      <div className="detail detail--empty">
        <span className="eyebrow">NO COMPONENT SELECTED</span>
        <p>Click or tap a part in the 3D view, or choose one from the list.</p>
      </div>
    );
  }
  const info = getComponentInfo(selected);
  return (
    <div className="detail">
      <div className="detail__head">
        <div>
          <span className="eyebrow">SELECTED · {info.role.toUpperCase()}</span>
          <h3>{info.label}</h3>
        </div>
        <IconButton icon={X} label="Deselect component" onClick={() => selectGroup(null)} sound="back" />
      </div>
      <p>{info.description}</p>
      <div className="detail__actions">
        <button type="button" className={cx('btn', isolate && 'is-active')} onClick={() => { sfx('click'); toggleIsolate(); }}>
          <Focus size={14} /> {isolate ? 'Isolated' : 'Isolate'}
        </button>
        <button type="button" className="btn" onClick={() => { sfx('click'); toggleHidden(selected); }}>
          {hidden[selected] ? <Eye size={14} /> : <EyeOff size={14} />} {hidden[selected] ? 'Show' : 'Hide'}
        </button>
      </div>
    </div>
  );
}
