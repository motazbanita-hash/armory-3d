import { useEffect, useState } from 'react';
import { PRODUCTS } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { cx } from '../../utils/math';
import Logo from '../Navigation/Logo';

const STEPS = ['INITIALIZING RENDERER', 'LOADING CATALOG', 'LOADING REFERENCE IMAGES', 'BUILDING 3D PROXIES', 'READY'];

function preload(src) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = img.onerror = resolve; // a missing image must never block the app
    img.src = src;
  });
}

/** Branded loading screen. Preloads the reference photos, then fades out. */
export default function LoadingScreen() {
  const ready = useArmoryStore((s) => s.ready);
  const setReady = useArmoryStore((s) => s.setReady);
  const [progress, setProgress] = useState(0);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    let live = true;
    const started = performance.now();
    const minTime = useArmoryStore.getState().isReducedMotion() ? 200 : 1600;
    let done = 0;
    const imgs = PRODUCTS.map((p) => preload(p.image).then(() => live && setProgress(++done / PRODUCTS.length)));
    Promise.all(imgs).then(() => {
      const wait = Math.max(0, minTime - (performance.now() - started));
      setTimeout(() => live && setReady(), wait);
    });
    // a failure to finish must never trap the user on this screen
    const safety = setTimeout(() => live && setReady(), 6000);
    return () => {
      live = false;
      clearTimeout(safety);
    };
  }, [setReady]);

  useEffect(() => {
    if (!ready) return undefined;
    const t = setTimeout(() => setGone(true), 700);
    return () => clearTimeout(t);
  }, [ready]);

  if (gone) return null;
  const step = ready ? STEPS.length - 1 : Math.min(STEPS.length - 2, Math.floor(progress * (STEPS.length - 1)));

  return (
    <div className={cx('loading', ready && 'is-done')} role="status" aria-live="polite">
      <div className="loading__inner">
        <Logo />
        <div className="loading__bar" aria-hidden="true">
          <span style={{ transform: `scaleX(${ready ? 1 : 0.08 + progress * 0.85})` }} />
        </div>
        <p>{STEPS[step]}</p>
      </div>
      <span className="loading__corner loading__corner--tl" />
      <span className="loading__corner loading__corner--br" />
    </div>
  );
}
