import { useMemo } from 'react';
import { Heart, Search } from 'lucide-react';
import { getCategory } from '../../data/categories';
import { productsInCategory, searchProducts } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';

/** FPS-style loadout list: one card per unit, with thumbnail, identifier, selection bracket. */
export default function ProductSelector() {
  const category = useArmoryStore((s) => s.category);
  const productId = useArmoryStore((s) => s.productId);
  const query = useArmoryStore((s) => s.query);
  const favoritesOnly = useArmoryStore((s) => s.favoritesOnly);
  const favorites = useArmoryStore((s) => s.favorites);
  const setQuery = useArmoryStore((s) => s.setQuery);
  const selectProduct = useArmoryStore((s) => s.selectProduct);
  const toggleFavorite = useArmoryStore((s) => s.toggleFavorite);
  const toggleFavoritesOnly = useArmoryStore((s) => s.toggleFavoritesOnly);

  const total = productsInCategory(category).length;
  const list = useMemo(
    () => searchProducts(query, { categoryId: category }).filter((p) => !favoritesOnly || favorites.includes(p.id)),
    [query, category, favoritesOnly, favorites]
  );

  return (
    <div className="selector">
      <div className="panel-head">
        <span className="eyebrow">SELECT UNIT</span>
        <h2>{getCategory(category)?.label}</h2>
        <span className="panel-head__count">
          {list.length}/{total}
        </span>
      </div>

      <div className="filter">
        <label className="filter__field">
          <Search size={15} aria-hidden="true" />
          <input
            type="search"
            value={query}
            placeholder="Filter units…"
            aria-label="Filter units"
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <IconButton
          icon={Heart}
          label={favoritesOnly ? 'Showing favorites only' : 'Show favorites only'}
          active={favoritesOnly}
          onClick={toggleFavoritesOnly}
        />
      </div>

      <ul className="cards">
        {list.map((p) => {
          const index = productsInCategory(category).findIndex((x) => x.id === p.id) + 1;
          const active = p.id === productId;
          const fav = favorites.includes(p.id);
          return (
            <li key={p.id} className={cx('pcard', active && 'is-active')}>
              <button
                type="button"
                className="pcard__main"
                aria-current={active ? 'true' : undefined}
                onClick={() => {
                  if (!active) {
                    selectProduct(p.id);
                    sfx('product');
                  }
                }}
              >
                <span className="pcard__index">{String(index).padStart(2, '0')}</span>
                <span className="pcard__thumb">
                  <img src={p.image} alt={`${p.identifier} reference photo`} loading="lazy" />
                </span>
                <span className="pcard__text">
                  <strong>{p.identifier}</strong>
                  <span>{p.name}</span>
                </span>
              </button>
              <button
                type="button"
                className={cx('pcard__fav', fav && 'is-on')}
                aria-label={fav ? `Remove ${p.identifier} from favorites` : `Add ${p.identifier} to favorites`}
                aria-pressed={fav}
                onClick={() => toggleFavorite(p.id)}
              >
                <Heart size={14} fill={fav ? 'currentColor' : 'none'} />
              </button>
              <i className="pcard__corner pcard__corner--tl" />
              <i className="pcard__corner pcard__corner--br" />
            </li>
          );
        })}
      </ul>

      {total === 0 && <p className="empty">No equipment in this category yet.</p>}
      {total > 0 && list.length === 0 && <p className="empty">No units match your filter.</p>}

      <p className="selector__hint">
        <kbd>←</kbd> <kbd>→</kbd> navigate · <kbd>1</kbd>–<kbd>{Math.max(total, 1)}</kbd> select
      </p>
    </div>
  );
}
