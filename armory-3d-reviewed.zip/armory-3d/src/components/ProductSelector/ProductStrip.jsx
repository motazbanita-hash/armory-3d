import { useEffect, useRef } from 'react';
import { productsInCategory } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';

/** Mobile: horizontally scrollable product selector. */
export default function ProductStrip() {
  const category = useArmoryStore((s) => s.category);
  const productId = useArmoryStore((s) => s.productId);
  const selectProduct = useArmoryStore((s) => s.selectProduct);
  const favorites = useArmoryStore((s) => s.favorites);
  const ref = useRef(null);
  const list = productsInCategory(category);

  useEffect(() => {
    ref.current?.querySelector('.is-active')?.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
  }, [productId]);

  if (!list.length) return <div className="strip strip--empty">No equipment in this category yet</div>;

  return (
    <div className="strip" ref={ref} role="listbox" aria-label="Select product">
      {list.map((p, i) => (
        <button
          key={p.id}
          type="button"
          role="option"
          aria-selected={p.id === productId}
          className={cx('scard', p.id === productId && 'is-active')}
          onClick={() => {
            if (p.id !== productId) {
              selectProduct(p.id);
              sfx('product');
            }
          }}
        >
          <span className="scard__thumb">
            <img src={p.image} alt="" loading="lazy" />
          </span>
          <span className="scard__text">
            <small>{String(i + 1).padStart(2, '0')}{favorites.includes(p.id) ? ' ♥' : ''}</small>
            <strong>{p.identifier}</strong>
          </span>
        </button>
      ))}
    </div>
  );
}
