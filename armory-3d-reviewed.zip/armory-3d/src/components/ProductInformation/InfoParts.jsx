import { Heart } from 'lucide-react';
import { getCategory } from '../../data/categories';
import { NOT_PROVIDED, getSpecRows } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';

export function ProductSummary({ product }) {
  const favorites = useArmoryStore((s) => s.favorites);
  const toggleFavorite = useArmoryStore((s) => s.toggleFavorite);
  const fav = favorites.includes(product.id);
  return (
    <div className="summary">
      <div className="summary__top">
        <div>
          <span className="eyebrow">{product.identifier}</span>
          <h2>{product.name}</h2>
        </div>
        <IconButton
          icon={Heart}
          className="fav"
          active={fav}
          label={fav ? 'Remove from favorites' : 'Add to favorites'}
          onClick={() => toggleFavorite(product.id)}
        />
      </div>
      <span className="tag">{getCategory(product.category)?.label}</span>
      <p>{product.description}</p>
    </div>
  );
}

export function FeatureList({ product }) {
  return (
    <ul className="features">
      {product.features.map((f) => (
        <li key={f}>{f}</li>
      ))}
    </ul>
  );
}

export function SpecTable({ product }) {
  return (
    <>
      <dl className="specs">
        {getSpecRows(product).map((r) => (
          <div key={r.label} className={cx('specs__row', !r.known && 'is-unknown')}>
            <dt>{r.label}</dt>
            <dd>{r.known ? r.value : NOT_PROVIDED}</dd>
          </div>
        ))}
      </dl>
      <p className="note">Specifications are shown only where supplied. Nothing here is estimated.</p>
    </>
  );
}

export function VisualTable({ product }) {
  return (
    <dl className="specs specs--visual">
      {product.visual.map((r) => (
        <div key={r.label} className="specs__row">
          <dt>{r.label}</dt>
          <dd>{r.value}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Section({ title, children, aside }) {
  return (
    <section className="section">
      <header className="section__head">
        <h3>{title}</h3>
        {aside}
      </header>
      {children}
    </section>
  );
}
