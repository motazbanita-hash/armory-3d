import { getProduct, productsInCategory } from '../../data/products';
import { getCategory } from '../../data/categories';
import { useArmoryStore } from '../../store/useArmoryStore';
import { ComponentDetail, ComponentExplorer } from '../ComponentExplorer/ComponentExplorer';
import { FeatureList, ProductSummary, Section, SpecTable, VisualTable } from './InfoParts';

/** Desktop right sidebar: everything about the selected product, kept in sync with the viewer. */
export default function ProductInfo() {
  const productId = useArmoryStore((s) => s.productId);
  const category = useArmoryStore((s) => s.category);

  if (productsInCategory(category).length === 0) {
    return (
      <div className="info">
        <div className="panel-head">
          <span className="eyebrow">DETAILS</span>
          <h2>{getCategory(category)?.label}</h2>
        </div>
        <p className="empty">Select a unit to see its details.</p>
      </div>
    );
  }

  const product = getProduct(productId);
  return (
    <div className="info" key={product.id}>
      <ProductSummary product={product} />
      <Section title="COMPONENT">
        <ComponentDetail />
      </Section>
      <Section title="COMPONENTS">
        <ComponentExplorer product={product} />
      </Section>
      <Section title="KEY FEATURES">
        <FeatureList product={product} />
      </Section>
      <Section title="SPECIFICATIONS">
        <SpecTable product={product} />
      </Section>
      <Section title="VISUAL CHARACTERISTICS">
        <VisualTable product={product} />
      </Section>
    </div>
  );
}
