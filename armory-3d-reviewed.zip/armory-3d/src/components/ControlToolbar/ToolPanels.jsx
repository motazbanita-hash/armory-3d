import { X } from 'lucide-react';
import { getProduct } from '../../data/products';
import { CAMERA_PRESETS } from '../../systems/CameraManager/cameraRuntime';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';
import LayerPanel from '../LayerPanel/LayerPanel';

function ExplodePanel() {
  const explode = useArmoryStore((s) => s.explode);
  const setExplode = useArmoryStore((s) => s.setExplode);
  const collapse = useArmoryStore((s) => s.collapse);
  const pct = Math.round(explode * 100);
  return (
    <div className="explode">
      <label className="slider">
        <span>
          Separation <em>{pct}%</em>
        </span>
        <input
          type="range"
          min="0"
          max="100"
          value={pct}
          onChange={(e) => setExplode(Number(e.target.value) / 100)}
          aria-label="Explode amount"
        />
      </label>
      <div className="explode__row">
        <button type="button" className="btn" disabled={pct === 0} onClick={() => { sfx('back'); collapse(); }}>
          Collapse
        </button>
        <button type="button" className="btn" onClick={() => { sfx('click'); setExplode(0.5); }}>
          50%
        </button>
        <button type="button" className="btn" onClick={() => { sfx('click'); setExplode(1); }}>
          Full
        </button>
      </div>
      <p className="note">Each component travels along its own configured exploded layout. Select a part to inspect it while apart.</p>
    </div>
  );
}

function ViewsPanel() {
  const cameraCommand = useArmoryStore((s) => s.cameraCommand);
  return (
    <div className="views">
      {CAMERA_PRESETS.map((p) => (
        <button key={p.id} type="button" className="btn" onClick={() => { sfx('click'); cameraCommand('preset', p.id); }}>
          {p.label}
        </button>
      ))}
    </div>
  );
}

const TITLES = { explode: 'EXPLODE VIEW', layers: 'LAYERS', views: 'CAMERA VIEWS' };

/** The popover (desktop) / bottom sheet (mobile) opened from the toolbar. */
export default function ToolPanels({ compact }) {
  const active = useArmoryStore((s) => s.activePanel);
  const closePanel = useArmoryStore((s) => s.closePanel);
  const productId = useArmoryStore((s) => s.productId);
  if (!active) return null;

  return (
    <div className={cx('toolpanel', compact && 'toolpanel--compact')} role="region" aria-label={TITLES[active]}>
      <header>
        <h3>{TITLES[active]}</h3>
        <IconButton icon={X} label="Close panel" onClick={closePanel} sound="back" />
      </header>
      {active === 'explode' && <ExplodePanel />}
      {active === 'layers' && <LayerPanel product={getProduct(productId)} />}
      {active === 'views' && <ViewsPanel />}
    </div>
  );
}
