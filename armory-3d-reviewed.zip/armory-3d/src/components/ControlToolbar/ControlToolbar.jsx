import { Boxes, Camera, Focus, Layers, Minus, Move, Plus, RefreshCw, Rotate3d, RotateCcw, Scan, ZoomIn } from 'lucide-react';
import { productsInCategory } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';

const Divider = () => <span className="toolbar__div" aria-hidden="true" />;

/** Bottom control panel. Every button changes real viewer state — nothing here is decorative. */
export default function ControlToolbar({ compact }) {
  const category = useArmoryStore((s) => s.category);
  const mode = useArmoryStore((s) => s.mode);
  const tool = useArmoryStore((s) => s.tool);
  const activePanel = useArmoryStore((s) => s.activePanel);
  const explode = useArmoryStore((s) => s.explode);
  const isolate = useArmoryStore((s) => s.isolate);
  const selected = useArmoryStore((s) => s.selectedGroup);
  const hidden = useArmoryStore((s) => s.hidden);
  const autoRotate = useArmoryStore((s) => s.autoRotate);
  const setMode = useArmoryStore((s) => s.setMode);
  const setTool = useArmoryStore((s) => s.setTool);
  const togglePanel = useArmoryStore((s) => s.togglePanel);
  const toggleIsolate = useArmoryStore((s) => s.toggleIsolate);
  const toggleAutoRotate = useArmoryStore((s) => s.toggleAutoRotate);
  const cameraCommand = useArmoryStore((s) => s.cameraCommand);
  const resetExperience = useArmoryStore((s) => s.resetExperience);

  const empty = productsInCategory(category).length === 0;
  const cap = (text) => (compact ? text : text);
  const inspection = mode === 'inspection';
  const hasHidden = Object.values(hidden).some(Boolean);

  return (
    <div className={cx('toolbar', compact && 'toolbar--compact')} role="toolbar" aria-label="Viewer controls">
      <IconButton
        icon={Scan}
        caption={cap('Inspect')}
        label={inspection ? 'Inspection mode on — switch to Cinematic' : 'Enter Inspection mode (I)'}
        active={inspection}
        sound="mode"
        disabled={empty}
        onClick={() => setMode(inspection ? 'cinematic' : 'inspection')}
      />
      <IconButton
        icon={Boxes}
        caption={cap('Explode')}
        label="Explode view (E)"
        active={activePanel === 'explode' || explode > 0}
        disabled={empty}
        onClick={() => togglePanel('explode')}
      />
      <IconButton
        icon={Layers}
        caption={cap('Layers')}
        label="Layers (L)"
        active={activePanel === 'layers' || hasHidden}
        disabled={empty}
        onClick={() => togglePanel('layers')}
      />
      <IconButton
        icon={Focus}
        caption={cap('Isolate')}
        label={selected ? 'Isolate selected component (O)' : 'Select a component to isolate it'}
        active={isolate}
        disabled={empty || !selected}
        onClick={toggleIsolate}
      />

      <Divider />

      <IconButton icon={Rotate3d} caption={cap('Rotate')} label="Drag to rotate" active={tool === 'rotate'} disabled={empty} onClick={() => setTool('rotate')} />
      <IconButton icon={Move} caption={cap('Pan')} label="Drag to pan" active={tool === 'pan'} disabled={empty} onClick={() => setTool('pan')} />
      <div className="toolbar__zoom">
        <IconButton icon={Minus} label="Zoom out" size={15} disabled={empty} onClick={() => cameraCommand('zoom', -1)} />
        <IconButton icon={ZoomIn} caption={cap('Zoom')} label="Drag to zoom" active={tool === 'zoom'} disabled={empty} onClick={() => setTool('zoom')} />
        <IconButton icon={Plus} label="Zoom in" size={15} disabled={empty} onClick={() => cameraCommand('zoom', 1)} />
      </div>

      <Divider />

      <IconButton icon={Camera} caption={cap('Views')} label="Camera views (V)" active={activePanel === 'views'} disabled={empty} onClick={() => togglePanel('views')} />
      <IconButton icon={RotateCcw} caption={cap('Reset')} label="Reset product, camera, layers and explode (R)" disabled={empty} sound="back" onClick={resetExperience} />
      <IconButton
        icon={RefreshCw}
        caption={cap('Auto')}
        label={autoRotate ? 'Auto-rotate on (Space)' : 'Auto-rotate off (Space)'}
        active={autoRotate}
        disabled={empty}
        onClick={() => {
          toggleAutoRotate();
          sfx('click');
        }}
        sound={null}
      />
    </div>
  );
}
