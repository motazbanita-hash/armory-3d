import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';

/**
 * Icon button used across the interface. Plays the UI click sound (when audio is on).
 * `caption` renders a small label under the icon (used by the toolbar).
 */
export default function IconButton({
  icon: Icon,
  label,
  caption,
  active,
  disabled,
  onClick,
  size = 18,
  className,
  sound = 'click',
  ...rest
}) {
  return (
    <button
      type="button"
      className={cx('ibtn', active && 'is-active', caption && 'ibtn--caption', className)}
      aria-label={label}
      title={label}
      aria-pressed={active === undefined ? undefined : !!active}
      disabled={disabled}
      onClick={(e) => {
        if (sound) sfx(sound);
        onClick?.(e);
      }}
      {...rest}
    >
      {Icon && <Icon size={size} strokeWidth={1.6} aria-hidden="true" />}
      {caption && <span className="ibtn__caption">{caption}</span>}
    </button>
  );
}
