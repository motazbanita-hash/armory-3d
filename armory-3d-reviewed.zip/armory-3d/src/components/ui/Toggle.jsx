import { sfx } from '../../utils/audio';

export default function Toggle({ label, description, checked, onChange }) {
  return (
    <div className="toggle">
      <div>
        <strong>{label}</strong>
        {description && <p>{description}</p>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        className="switch"
        onClick={() => {
          sfx('click');
          onChange(!checked);
        }}
      >
        <span />
      </button>
    </div>
  );
}
