import { Component } from 'react';

/** Generic error boundary. `fallback` can be a node or (error, reset) => node. */
export default class ErrorBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error) {
    this.props.onError?.(error);
    // eslint-disable-next-line no-console
    console.warn('[ARMORY 3D]', error);
  }

  reset = () => this.setState({ error: null });

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const { fallback } = this.props;
    return typeof fallback === 'function' ? fallback(error, this.reset) : fallback ?? null;
  }
}
