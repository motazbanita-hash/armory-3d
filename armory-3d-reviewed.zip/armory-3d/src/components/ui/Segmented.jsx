import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';

/** Small segmented control. options: [{ id, label, icon? }] */
export default function Segmented({ options, value, onChange, className, ariaLabel }) {
  return (
    <div className={cx('seg', className)} role="group" aria-label={ariaLabel}>
      {options.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          type="button"
          className={cx('seg__item', value === id && 'is-active')}
          aria-pressed={value === id}
          onClick={() => {
            if (value !== id) {
              sfx('mode');
              onChange(id);
            }
          }}
        >
          {Icon && <Icon size={14} strokeWidth={1.8} aria-hidden="true" />}
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
}
