import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import IconButton from './IconButton';
import { cx } from '../../utils/math';

/** Overlay dialog. Closes on backdrop click or the close button (Esc is handled globally). */
export default function Modal({ title, eyebrow, onClose, wide, children }) {
  const ref = useRef(null);

  useEffect(() => {
    const prev = document.activeElement;
    ref.current?.focus();
    return () => prev?.focus?.();
  }, []);

  return (
    <div className="modal" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        className={cx('modal__card', wide && 'modal__card--wide')}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={ref}
      >
        <header className="modal__head">
          <div>
            {eyebrow && <span className="eyebrow">{eyebrow}</span>}
            <h2>{title}</h2>
          </div>
          <IconButton icon={X} label="Close" onClick={onClose} sound="back" />
        </header>
        <div className="modal__body">{children}</div>
      </div>
    </div>
  );
}
