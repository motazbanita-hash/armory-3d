import { useRef } from 'react';
import { ChevronUp, X } from 'lucide-react';
import { getProduct } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';
import Segmented from '../ui/Segmented';
import { ComponentDetail, ComponentExplorer } from '../ComponentExplorer/ComponentExplorer';
import { FeatureList, ProductSummary, Section, SpecTable, VisualTable } from '../ProductInformation/InfoParts';

const TABS = [
  { id: 'info', label: 'Info' },
  { id: 'parts', label: 'Parts' },
  { id: 'specs', label: 'Specs' },
];

/** Mobile: expandable product information + component sheet. Collapsed = a peek bar. */
export default function MobileSheet() {
  const open = useArmoryStore((s) => s.infoOpen);
  const tab = useArmoryStore((s) => s.infoTab);
  const productId = useArmoryStore((s) => s.productId);
  const selected = useArmoryStore((s) => s.selectedGroup);
  const setOpen = useArmoryStore((s) => s.setInfoOpen);
  const setTab = useArmoryStore((s) => s.setInfoTab);
  const product = getProduct(productId);
  const drag = useRef(null);

  const onTouchStart = (e) => {
    drag.current = e.touches[0].clientY;
  };
  const onTouchEnd = (e) => {
    if (drag.current == null) return;
    const dy = e.changedTouches[0].clientY - drag.current;
    drag.current = null;
    if (dy > 50) setOpen(false);
    else if (dy < -50) setOpen(true);
  };

  return (
    <aside className={cx('sheet', open && 'is-open')} aria-label="Product information">
      <div className="sheet__handle" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        <button
          type="button"
          className="sheet__peek"
          aria-expanded={open}
          onClick={() => {
            sfx('click');
            setOpen(!open);
          }}
        >
          <span className="sheet__grip" aria-hidden="true" />
          <span className="sheet__title">
            <small>{selected ? 'COMPONENT SELECTED' : product.identifier}</small>
            <strong>{product.name}</strong>
          </span>
          {open ? <X size={18} /> : <ChevronUp size={18} />}
        </button>
      </div>
      {open && (
        <div className="sheet__body">
          <Segmented options={TABS} value={tab} onChange={setTab} ariaLabel="Information sections" className="sheet__tabs" />
          {tab === 'info' && (
            <>
              <ProductSummary product={product} />
              <Section title="KEY FEATURES">
                <FeatureList product={product} />
              </Section>
            </>
          )}
          {tab === 'parts' && (
            <>
              <Section title="COMPONENT">
                <ComponentDetail />
              </Section>
              <Section title="COMPONENTS">
                <ComponentExplorer product={product} />
              </Section>
            </>
          )}
          {tab === 'specs' && (
            <>
              <Section title="SPECIFICATIONS">
                <SpecTable product={product} />
              </Section>
              <Section title="VISUAL CHARACTERISTICS">
                <VisualTable product={product} />
              </Section>
            </>
          )}
        </div>
      )}
    </aside>
  );
}
