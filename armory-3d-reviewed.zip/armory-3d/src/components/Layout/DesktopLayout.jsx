import { useArmoryStore } from '../../store/useArmoryStore';
import { cx } from '../../utils/math';
import TopNav from '../Navigation/TopNav';
import ProductSelector from '../ProductSelector/ProductSelector';
import ProductViewer from '../ProductViewer/ProductViewer';
import ProductInfo from '../ProductInformation/ProductInfo';
import ControlToolbar from '../ControlToolbar/ControlToolbar';
import ToolPanels from '../ControlToolbar/ToolPanels';

/** Desktop / laptop / landscape tablet: nav · selector | viewer | info · control panel. */
export default function DesktopLayout() {
  const focus = useArmoryStore((s) => s.focus);
  return (
    <div className={cx('shell shell--desktop', focus && 'is-focus')}>
      {!focus && <TopNav />}
      <main className="stage">
        {!focus && (
          <aside className="side side--left" aria-label="Product selection">
            <ProductSelector />
          </aside>
        )}
        <section className="center" aria-label="3D viewer">
          <ProductViewer />
          <div className="center__dock">
            <ToolPanels />
            <ControlToolbar />
          </div>
        </section>
        {!focus && (
          <aside className="side side--right" aria-label="Product information">
            <ProductInfo />
          </aside>
        )}
      </main>
    </div>
  );
}
