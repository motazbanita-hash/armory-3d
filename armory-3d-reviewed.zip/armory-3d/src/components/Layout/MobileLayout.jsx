import { Search } from 'lucide-react';
import { useArmoryStore } from '../../store/useArmoryStore';
import { cx } from '../../utils/math';
import Logo from '../Navigation/Logo';
import { CategoryTabs, NavActions } from '../Navigation/TopNav';
import ProductStrip from '../ProductSelector/ProductStrip';
import ProductViewer from '../ProductViewer/ProductViewer';
import ControlToolbar from '../ControlToolbar/ControlToolbar';
import ToolPanels from '../ControlToolbar/ToolPanels';
import MobileSheet from './MobileSheet';

/** Dedicated mobile experience: compact nav, full-width viewer, product strip, bottom toolbar, info sheet. */
export default function MobileLayout() {
  const focus = useArmoryStore((s) => s.focus);
  const infoOpen = useArmoryStore((s) => s.infoOpen);
  return (
    <div className={cx('shell shell--mobile', focus && 'is-focus', infoOpen && 'sheet-open')}>
      {!focus && (
        <header className="mnav">
          <div className="mnav__row">
            <Logo compact />
            <NavActions />
          </div>
          <CategoryTabs className="cats--scroll" />
        </header>
      )}
      <main className="mstage">
        <section className="mviewer" aria-label="3D viewer">
          <ProductViewer compact />
          <ToolPanels compact />
        </section>
        {!focus && <ProductStrip />}
        <ControlToolbar compact />
        {!focus && <MobileSheet />}
      </main>
    </div>
  );
}
