import { useEffect, useMemo, useRef, useState } from 'react';
import { Search } from 'lucide-react';
import { getCategory } from '../../data/categories';
import { searchProducts } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import Modal from '../ui/Modal';

/** Global search across all categories by name, identifier, category and features. */
export default function SearchModal() {
  const setSearchOpen = useArmoryStore((s) => s.setSearchOpen);
  const selectProduct = useArmoryStore((s) => s.selectProduct);
  const [q, setQ] = useState('');
  const [cursor, setCursor] = useState(0);
  const input = useRef(null);
  const results = useMemo(() => searchProducts(q), [q]);

  useEffect(() => {
    input.current?.focus();
  }, []);
  useEffect(() => setCursor(0), [q]);

  const choose = (p) => {
    selectProduct(p.id);
    setSearchOpen(false);
    sfx('product');
  };

  const onKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setCursor((c) => Math.min(c + 1, results.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setCursor((c) => Math.max(c - 1, 0));
    } else if (e.key === 'Enter' && results[cursor]) choose(results[cursor]);
  };

  return (
    <Modal title="Search equipment" eyebrow="DATABASE" onClose={() => setSearchOpen(false)}>
      <label className="search">
        <Search size={16} aria-hidden="true" />
        <input
          ref={input}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Search by name, colour or category…"
          aria-label="Search equipment"
        />
      </label>
      <ul className="results">
        {results.map((p, i) => (
          <li key={p.id}>
            <button type="button" className={cx('result', i === cursor && 'is-cursor')} onMouseEnter={() => setCursor(i)} onClick={() => choose(p)}>
              <img src={p.image} alt="" />
              <span>
                <strong>{p.identifier}</strong>
                <small>
                  {p.name} · {getCategory(p.category)?.label}
                </small>
              </span>
            </button>
          </li>
        ))}
      </ul>
      {results.length === 0 && <p className="empty">No equipment matches “{q}”.</p>}
    </Modal>
  );
}
