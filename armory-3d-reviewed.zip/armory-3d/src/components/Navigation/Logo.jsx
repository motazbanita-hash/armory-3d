export default function Logo({ compact = false }) {
  return (
    <div className="logo" aria-label="ARMORY 3D">
      <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true">
        <path d="M16 2.5 28 9.5v13L16 29.5 4 22.5v-13z" fill="none" stroke="#C3A36A" strokeWidth="1.6" />
        <path d="M16 9v14M9.5 12.8 22.5 19.2M22.5 12.8 9.5 19.2" stroke="#8F774B" strokeWidth="1.2" />
        <circle cx="16" cy="16" r="2.6" fill="#C3A36A" />
      </svg>
      <div className="logo__text">
        <span className="logo__word">
          ARMORY<em>3D</em>
        </span>
        {!compact && <span className="logo__tag">EXPLORE. INSPECT. DISCOVER.</span>}
      </div>
    </div>
  );
}
