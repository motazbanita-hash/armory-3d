import { GitCompare, Maximize, Minimize, Search, Settings, Volume2, VolumeX } from 'lucide-react';
import { CATEGORIES } from '../../data/categories';
import { productsInCategory } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { useFullscreen } from '../../hooks/useFullscreen';
import { cx } from '../../utils/math';
import { sfx } from '../../utils/audio';
import IconButton from '../ui/IconButton';
import Logo from './Logo';

/** Category tabs (desktop shows them inline, mobile as a scroller). */
export function CategoryTabs({ className }) {
  const category = useArmoryStore((s) => s.category);
  const setCategory = useArmoryStore((s) => s.setCategory);
  return (
    <nav className={cx('cats', className)} aria-label="Equipment categories">
      {CATEGORIES.map((c) => {
        const count = productsInCategory(c.id).length;
        return (
          <button
            key={c.id}
            type="button"
            className={cx('cats__item', category === c.id && 'is-active', count === 0 && 'is-empty')}
            aria-current={category === c.id ? 'page' : undefined}
            onClick={() => {
              sfx('click');
              setCategory(c.id);
            }}
          >
            {c.label}
            <small>{count || '—'}</small>
          </button>
        );
      })}
    </nav>
  );
}

/** Search / compare / sound / settings / fullscreen. */
export function NavActions() {
  const audioOn = useArmoryStore((s) => s.audioOn);
  const setSetting = useArmoryStore((s) => s.setSetting);
  const setSearchOpen = useArmoryStore((s) => s.setSearchOpen);
  const setSettingsOpen = useArmoryStore((s) => s.setSettingsOpen);
  const setCompareOpen = useArmoryStore((s) => s.setCompareOpen);
  const { focus, toggle } = useFullscreen();

  return (
    <div className="nav__tools">
      <IconButton icon={Search} label="Search (Ctrl K)" onClick={() => setSearchOpen(true)} />
      <IconButton icon={GitCompare} label="Compare products (C)" onClick={() => setCompareOpen(true)} />
      <IconButton
        icon={audioOn ? Volume2 : VolumeX}
        label={audioOn ? 'Sound effects on' : 'Sound effects off'}
        active={audioOn}
        sound={null}
        onClick={() => {
          setSetting('audioOn', !audioOn);
          // play a confirmation blip only when turning ON (the store value updates synchronously)
          sfx('click');
        }}
      />
      <IconButton icon={Settings} label="Settings" onClick={() => setSettingsOpen(true)} />
      <IconButton
        icon={focus ? Minimize : Maximize}
        label={focus ? 'Exit fullscreen (F)' : 'Fullscreen (F)'}
        active={focus}
        onClick={toggle}
      />
    </div>
  );
}

export default function TopNav() {
  return (
    <header className="nav">
      <Logo />
      <CategoryTabs />
      <NavActions />
    </header>
  );
}
