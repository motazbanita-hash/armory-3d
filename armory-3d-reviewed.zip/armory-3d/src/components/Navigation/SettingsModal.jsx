import { SHORTCUTS } from '../../hooks/useKeyboardShortcuts';
import { useArmoryStore } from '../../store/useArmoryStore';
import Modal from '../ui/Modal';
import Segmented from '../ui/Segmented';
import Toggle from '../ui/Toggle';

export default function SettingsModal() {
  const s = useArmoryStore();
  const set = s.setSetting;
  return (
    <Modal title="Settings" eyebrow="SYSTEM" onClose={() => s.setSettingsOpen(false)}>
      <div className="settings">
        <Toggle label="Sound effects" description="Short synthesized interface sounds." checked={s.audioOn} onChange={(v) => set('audioOn', v)} />
        <Toggle label="Propeller spin" description="Spin the propellers while the model is assembled." checked={s.propSpin} onChange={(v) => set('propSpin', v)} />
        <Toggle label="Shadows" description="Soft contact shadows on the platform." checked={s.shadows} onChange={(v) => set('shadows', v)} />
        <Toggle label="Technical grid" description="Show the floor grid." checked={s.showGrid} onChange={(v) => set('showGrid', v)} />

        <div className="toggle">
          <div>
            <strong>Graphics quality</strong>
            <p>Low renders at 1× resolution — use it on older devices.</p>
          </div>
          <Segmented
            ariaLabel="Graphics quality"
            value={s.quality}
            onChange={(v) => set('quality', v)}
            options={[
              { id: 'auto', label: 'Auto' },
              { id: 'low', label: 'Low' },
            ]}
          />
        </div>
        <div className="toggle">
          <div>
            <strong>Motion</strong>
            <p>Follows your system setting unless you reduce it here.</p>
          </div>
          <Segmented
            ariaLabel="Motion"
            value={s.motion}
            onChange={(v) => set('motion', v)}
            options={[
              { id: 'system', label: 'System' },
              { id: 'reduce', label: 'Reduced' },
            ]}
          />
        </div>

        <h4 className="cmp__title">KEYBOARD SHORTCUTS</h4>
        <dl className="shortcuts">
          {SHORTCUTS.map(([k, d]) => (
            <div key={k}>
              <dt>
                <kbd>{k}</kbd>
              </dt>
              <dd>{d}</dd>
            </div>
          ))}
        </dl>
      </div>
    </Modal>
  );
}
