import { Eye, EyeOff, Focus } from 'lucide-react';
import { getProductGroups } from '../../data/components';
import { useArmoryStore } from '../../store/useArmoryStore';
import { sfx } from '../../utils/audio';
import { cx } from '../../utils/math';
import IconButton from '../ui/IconButton';

/** Layer manager UI. Every control writes to the store; the model runtime applies it to the meshes. */
export default function LayerPanel({ product }) {
  const hidden = useArmoryStore((s) => s.hidden);
  const selected = useArmoryStore((s) => s.selectedGroup);
  const xray = useArmoryStore((s) => s.xray);
  const toggleHidden = useArmoryStore((s) => s.toggleHidden);
  const showAll = useArmoryStore((s) => s.showAllLayers);
  const solo = useArmoryStore((s) => s.soloGroup);
  const setXray = useArmoryStore((s) => s.setXray);
  const selectGroup = useArmoryStore((s) => s.selectGroup);
  const setHover = useArmoryStore((s) => s.setHover);

  const groups = getProductGroups(product);
  const ids = groups.map((g) => g.id);
  const anyHidden = ids.some((id) => hidden[id]);

  return (
    <div className="layers">
      <ul>
        {groups.map((g) => (
          <li
            key={g.id}
            className={cx('layer', hidden[g.id] && 'is-hidden', selected === g.id && 'is-selected')}
            onMouseEnter={() => setHover(g.id)}
            onMouseLeave={() => setHover(null)}
          >
            <IconButton
              icon={hidden[g.id] ? EyeOff : Eye}
              label={hidden[g.id] ? `Show ${g.label}` : `Hide ${g.label}`}
              onClick={() => toggleHidden(g.id)}
            />
            <button
              type="button"
              className="layer__name"
              onClick={() => {
                sfx('select');
                selectGroup(selected === g.id ? null : g.id);
              }}
            >
              {g.label}
              <small>{g.count}</small>
            </button>
            <IconButton icon={Focus} label={`Show only ${g.label}`} onClick={() => solo(g.id, ids)} />
          </li>
        ))}
      </ul>

      <label className="slider">
        <span>
          Transparency <em>{Math.round(xray * 100)}%</em>
        </span>
        <input
          type="range"
          min="0"
          max="100"
          value={Math.round(xray * 100)}
          onChange={(e) => setXray(Number(e.target.value) / 100)}
          aria-label="Layer transparency"
        />
      </label>

      <button type="button" className="btn btn--block" disabled={!anyHidden && xray === 0} onClick={() => { sfx('back'); showAll(); }}>
        Restore all layers
      </button>
    </div>
  );
}
