import { ArrowLeftRight } from 'lucide-react';
import { PRODUCTS, getProduct, getSpecRows } from '../../data/products';
import { useArmoryStore } from '../../store/useArmoryStore';
import { cx } from '../../utils/math';
import { sfx } from '../../utils/audio';
import Modal from '../ui/Modal';

function Picker({ index }) {
  const compare = useArmoryStore((s) => s.compare);
  const setCompare = useArmoryStore((s) => s.setCompare);
  const other = compare[1 - index];
  return (
    <div className="cmp__picker" role="radiogroup" aria-label={`Unit ${index === 0 ? 'A' : 'B'}`}>
      {PRODUCTS.map((p) => (
        <button
          key={p.id}
          type="button"
          role="radio"
          aria-checked={compare[index] === p.id}
          disabled={p.id === other}
          className={cx(compare[index] === p.id && 'is-active')}
          onClick={() => {
            sfx('click');
            setCompare(index, p.id);
          }}
        >
          {p.identifier.replace('QUADCOPTER ', 'Q')}
        </button>
      ))}
    </div>
  );
}

/** Side-by-side comparison of any two catalog units. Only supplied facts are compared. */
export default function Comparison() {
  const compare = useArmoryStore((s) => s.compare);
  const setCompareOpen = useArmoryStore((s) => s.setCompareOpen);
  const swap = useArmoryStore((s) => s.swapCompare);
  const selectProduct = useArmoryStore((s) => s.selectProduct);
  const [a, b] = compare.map(getProduct);
  const specsA = getSpecRows(a);
  const specsB = getSpecRows(b);

  const diffs = a.visual.map((row, i) => ({ label: row.label, a: row.value, b: b.visual[i]?.value ?? '—' }));
  const open = (p) => {
    selectProduct(p.id);
    setCompareOpen(false);
    sfx('product');
  };

  return (
    <Modal title="Compare units" eyebrow="SIDE BY SIDE" wide onClose={() => setCompareOpen(false)}>
      <div className="cmp">
        <div className="cmp__heads">
          {[a, b].map((p, i) => (
            <div className="cmp__head" key={p.id}>
              <Picker index={i} />
              <img src={p.image} alt={`${p.identifier} reference photo`} />
              <span className="eyebrow">{p.identifier}</span>
              <h3>{p.name}</h3>
              <button type="button" className="btn" onClick={() => open(p)}>
                Inspect in 3D
              </button>
            </div>
          ))}
          <button type="button" className="cmp__swap" aria-label="Swap units" onClick={() => { sfx('click'); swap(); }}>
            <ArrowLeftRight size={16} />
          </button>
        </div>

        <h4 className="cmp__title">VISUAL DIFFERENCES</h4>
        <div className="cmp__table">
          {diffs.map((d) => (
            <div key={d.label} className={cx('cmp__row', d.a !== d.b && 'is-diff')}>
              <span className="cmp__cell">{d.a}</span>
              <span className="cmp__label">{d.label}</span>
              <span className="cmp__cell">{d.b}</span>
            </div>
          ))}
        </div>

        <h4 className="cmp__title">SPECIFICATIONS</h4>
        <div className="cmp__table">
          {specsA.map((r, i) => (
            <div key={r.label} className="cmp__row">
              <span className={cx('cmp__cell', !r.known && 'is-unknown')}>{r.value}</span>
              <span className="cmp__label">{r.label}</span>
              <span className={cx('cmp__cell', !specsB[i].known && 'is-unknown')}>{specsB[i].value}</span>
            </div>
          ))}
        </div>
        <p className="note">Highlighted rows differ. Specifications are shown only where supplied.</p>
      </div>
    </Modal>
  );
}
