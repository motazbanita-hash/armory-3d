import { lazy, Suspense, useMemo } from 'react';
import { PRODUCTS } from './data/products';
import { useArmoryStore } from './store/useArmoryStore';
import { useFullscreen } from './hooks/useFullscreen';
import { useIsCompact } from './hooks/useMediaQuery';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import DesktopLayout from './components/Layout/DesktopLayout';
import MobileLayout from './components/Layout/MobileLayout';
import LoadingScreen from './components/Overlays/LoadingScreen';
import ErrorBoundary from './components/ui/ErrorBoundary';

// Lazy: only loaded when opened.
const Comparison = lazy(() => import('./components/Comparison/Comparison'));
const SearchModal = lazy(() => import('./components/Navigation/SearchModal'));
const SettingsModal = lazy(() => import('./components/Navigation/SettingsModal'));

export default function App() {
  const compact = useIsCompact();
  const compareOpen = useArmoryStore((s) => s.compareOpen);
  const searchOpen = useArmoryStore((s) => s.searchOpen);
  const settingsOpen = useArmoryStore((s) => s.settingsOpen);
  const { toggle } = useFullscreen();
  const productIds = useMemo(() => PRODUCTS.map((p) => p.id), []);

  useKeyboardShortcuts({ toggleFullscreen: toggle, productIds });

  return (
    <>
      <ErrorBoundary fallback={<p className="fatal">Something went wrong. Please reload the page.</p>}>
        {compact ? <MobileLayout /> : <DesktopLayout />}
        <Suspense fallback={null}>
          {compareOpen && <Comparison />}
          {searchOpen && <SearchModal />}
          {settingsOpen && <SettingsModal />}
        </Suspense>
      </ErrorBoundary>
      <LoadingScreen />
    </>
  );
}
